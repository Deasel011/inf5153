package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

import java.awt.*;

/**
 * Created by Philippe on 2016-04-28.
 */
public class EndOfMatchPannel {
    Position GridPos;
    String message;
    boolean matchOver;
    EndOfMatchPannel(char RorL){
        if(RorL=='R'||RorL=='r'){
            GridPos = new Position(0.45f,-0.25f);
            message="Bravo!";
        } else if(RorL=='L'||RorL=='l'){
            GridPos = new Position(-0.45f,-0.25f);
            message="Dommage...";
        } else {
            assert(RorL=='R'||RorL=='r'||RorL=='L'||RorL=='l');
        }
    }


    public void drawEndOfMatchPannel(GL2 gl, TextRenderer renderer){
        float x=GridPos.getX();
        float y=GridPos.getY();
        int [] iPosition= new int [2];
        iPosition[0]=800+(int)(800*x);
        iPosition[1]=400+(int)(400*y);
        //background
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0f,0f,0.2f);
        gl.glVertex2f(x-0.25f,y+0.23f);
        gl.glVertex2f(x+0.25f,y+0.23f);
        gl.glVertex2f(x+0.25f,y-0.23f);
        gl.glVertex2f(x-0.25f,y-0.23f);
        gl.glEnd();

        renderer.beginRendering(1600, 800);
        // optionallowerY set the color
        renderer.setColor(Color.white);
        renderer.draw(message,iPosition[0]-30,iPosition[1]);
        // ... more draw commands, color changes, etc.
        renderer.endRendering();
    }

}
