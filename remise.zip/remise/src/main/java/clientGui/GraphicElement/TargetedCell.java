package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;

/**
 * Created by Philippe on 2016-04-28.
 */
public class TargetedCell {
    Position position;
    float[] color=new float[]{0.9f,0.5f,0.3f};
    TargetedCell(Position position){
        this.position=new Position(position);
    }

    public void changePosition(Position position){
        this.position=new Position(position);
    }

    public void drawTargetCell(GL2 gl){
        float x=position.getX();
        float y=position.getY();
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(.9f,0.5f,0.3f);
        gl.glVertex2f(x-0.0245f,y+0.0495f);
        gl.glVertex2f(x+0.0245f,y+0.0495f);
        gl.glVertex2f(x+0.0245f,y-0.0495f);
        gl.glVertex2f(x-0.0245f,y-0.0495f);
        gl.glEnd();
    }
}
