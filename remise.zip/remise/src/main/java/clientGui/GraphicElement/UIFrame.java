package clientGui.GraphicElement;

import com.jogamp.opengl.*;
import com.jogamp.opengl.util.awt.TextRenderer;

import java.awt.*;
import java.awt.event.*;



/**
 * Created by deasel on 2016-04-19.
 */
public class UIFrame implements GLEventListener, MouseListener, MouseMotionListener{
    TextRenderer renderer = new TextRenderer(new Font("SansSerif", Font.BOLD, 14)),
            gridRenderer =  new TextRenderer(new Font("SansSerif", Font.BOLD, 20));
    Elements elements = new Elements();
    double totalH=800.0;
    double totalW=1600.0;
    float mouseClickX;
    float mouseClickY;
    float mousePos[] = new float[]{0f,0f};
    static int stringCounter=0;
    int torpedoCounter=0;
    int frameCounter=0;

    public void init(GLAutoDrawable glAutoDrawable) {
        elements.addLeftGrid(new LeftGrid());
        elements.addRightGrid(new RightGrid());
        elements.addShipyard(new Shipyard(-1f,0.25f));

        //Initialisation des boutons
        elements.addButton(new Button("Quitter Partie",new float[]{-0.1125f,0.90f}));//0
        elements.buttons.get(0).upperX+=0.09f;
        elements.buttons.get(0).setAvailability(false);

        elements.addButton(new Button("Mystere",new float[]{-0.04f,0.32f}));//1
        elements.buttons.get(1).upperX+=0.02f;

        elements.addButton(new Button("Nouvelle Partie", new float[]{-0.1125f,0.8f}));//2
        elements.buttons.get(2).upperX+=0.12f;

        elements.addButton(new Button("Charger Partie", new float []{-0.1125f,0.7f}));//3
        elements.buttons.get(3).upperX+=0.105f;

        elements.addButton(new Button("Orientation", new float[]{-0.955f,-0.85f}));//4
        elements.buttons.get(4).upperX+=0.09f;
        elements.buttons.get(4).setAvailability(false);


        elements.addButton(new Button("Torpille", new float[]{0.4f, 0.4f}));//5
        elements.buttons.get(5).setAvailability(false);

        elements.addButton(new Button("Sauvegarder Partie", new float[]{-0.1125f,0.7f}));//6
        elements.buttons.get(6).upperX+=0.15f;
        elements.buttons.get(6).setAvailability(false);

        elements.addButton(new Button("Difficile", new float[]{-0.1125f,0.75f}));//7
        elements.buttons.get(7).setAvailability(false);
        elements.buttons.get(7).upperX+=0.03f;
        elements.addButton(new Button("Facile", new float[]{-0.1125f,0.65f}));//8
        elements.buttons.get(8).setAvailability(false);

        elements.addButton(new Button("Demarer", new float[]{-0.1125f,0.7f}));//9
        elements.buttons.get(9).setAvailability(false);
        elements.buttons.get(9).upperX+=0.03f;

        elements.addButton(new Button("Visualiser", new float[]{-0.04f,0.50f}));//10
        elements.buttons.get(10).setAvailability(false);
        elements.buttons.get(10).upperX+=0.04f;

        elements.addButton(new Button("Placement Automatique", new float[]{-0.9698f,0.35f}));//11
        elements.buttons.get(11).upperX+=0.22f;
        elements.buttons.get(11).setAvailability(false);


        elements.addCorporal(new Corporal());




    }

    public void dispose(GLAutoDrawable glAutoDrawable) {

    }

    public void display(GLAutoDrawable glAutoDrawable) {
        frameCounter++;
        if(frameCounter>59){frameCounter=0;}
        GL2 gl = glAutoDrawable.getGL().getGL2();
        GameBackground.drawGameBackground(gl,renderer);
        elements.leftGrid.drawLeftGrid(gl,gridRenderer);
        elements.rightGrid.drawRightGrid(gl,gridRenderer);
        elements.drawBoats(gl);
        elements.drawButtons(gl, gridRenderer);
        elements.drawShipyard(gl,renderer);

        //corporal talking
        if(elements.corporal.isTalking) {
            stringCounter++;
            elements.corporal.corporalSays(elements.activeQuote,stringCounter);
        } else if(!elements.buttons.get(1).isAvailable()){
            elements.buttons.get(1).setAvailability(true);
            stringCounter=0;
        }

        //afficher demarer
        if(elements.opponentReady&&elements.match.getAlgo()==null&&elements.boats.size()>=5){
            elements.buttons.get(9).setAvailability(true);
        }

        //Enlever placement automatique si un bateau est deja présent
        if(elements.shipyard.isAnyShipPlaced()){
            elements.buttons.get(11).setAvailability(false);
        }

        //affichage des coordonnées d'un click
        /*renderer.beginRendering(1600, 800);
        renderer.setColor(1.0f, 0.2f, 0.2f, 0.8f);
        renderer.draw(mousePos[0]+":"+mousePos[1], 0, 500);
        renderer.endRendering();*/

        elements.drawCorporal(gl, renderer);

        elements.drawTempBoat(gl);
        //en visualisation
        if(elements.isVisualizing){
            visualisationUpdate();
        }
        elements.drawTargetedCells(gl);
        elements.drawTorpedos(gl, (torpedoCounter++)/30);

        elements.drawPanneau(gl,renderer);
    }

    public void reshape(GLAutoDrawable glAutoDrawable, int i, int i1, int i2, int i3) {
        GL2 gl=glAutoDrawable.getGL().getGL2();
        int viewport[] = new int [4];
        gl.glGetIntegerv(GL.GL_VIEWPORT,viewport,0);
        totalH = viewport[3];
        totalW = viewport[2];
    }

    public void mouseClicked(MouseEvent e) {


    }

    public void mousePressed(MouseEvent e) {

        //Formule pour transformer les ints en floats
        mousePos[0]=(float)(e.getX()/(totalW/2.0))-1.0f;
        mousePos[1]=-((float)(e.getY()/(totalH/2.0))-1.0f);

    }

    public void mouseReleased(MouseEvent e) {
        mouseClickX=(float)(e.getX()/(totalW/2.0))-1.0f;
        mouseClickY=-((float)(e.getY()/(totalH/2.0))-1.0f);
        elements.checkClicked(mouseClickX,mouseClickY);
    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void mouseDragged(MouseEvent e) {

    }

    public void mouseMoved(MouseEvent e) {

    }

    public static void resetStringCounter(){
        stringCounter=0;
    }

    private void visualisationUpdate(){
        Torpedo tempTorpedo;
        if(elements.tempTorpedosList.isEmpty()){
            elements.buttons.get(0).setAvailability(true);
            elements.buttons.get(10).setAvailability(true);
            elements.isVisualizing=false;
            if(elements.match.getWinner()==elements.match.getSide1()){
                elements.panneau=new EndOfMatchPannel('r');
            } else {
                elements.panneau=new EndOfMatchPannel('l');
            }
            return;
        }
        if(frameCounter%20==0){
            tempTorpedo=elements.tempTorpedosList.remove(0);
            elements.torpedos.add(tempTorpedo);
            if(elements.playerTarget==null) {
                elements.playerTarget = new TargetedCell(new Position(tempTorpedo.position[0], tempTorpedo.position[1]));
            }else {
                elements.playerTarget.changePosition(new Position(tempTorpedo.position[0],tempTorpedo.position[1]));
            }
        }
        if((frameCounter+10)%20==0&&!elements.tempOpponentTorpedosList.isEmpty()){
            tempTorpedo=elements.tempOpponentTorpedosList.remove(0);
            elements.opponentTorpedos.add(tempTorpedo);
            if(elements.opponentTarget==null) {
                elements.opponentTarget = new TargetedCell(new Position(tempTorpedo.position[0], tempTorpedo.position[1]));
            }else {
                elements.opponentTarget.changePosition(new Position(tempTorpedo.position[0],tempTorpedo.position[1]));
            }
        }
    }
}
