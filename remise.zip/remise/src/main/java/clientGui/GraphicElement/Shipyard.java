package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

import javax.swing.*;

/**
 * Created by deasel on 2016-04-20.
 */
public class Shipyard implements gridElement{
    float x;
    float y;

    //bool sur le placement des bateaux
    Shipstate porteAvion;
    Shipstate croiseur;
    Shipstate contreTorpilleur;
    Shipstate sousMarin;
    Shipstate torpilleur;
    Boat tempBoat;
    char tempBoatSymbol;
    
    Shipyard(float x,float y){
        this.x=x;
        this.y=y;
        porteAvion = new Shipstate(new Boat(5,new float[]{x+0.05f,y-0.05f},true), "Porte Avion");
        croiseur = new Shipstate(new Boat(4,new float[]{x+0.15f,y-0.05f},true), "Croiseur");
        contreTorpilleur = new Shipstate(new Boat(3,new float[]{x+0.05f,y-0.60f},false), "Contre Torpilleur");
        sousMarin = new Shipstate(new Boat(3,new float[]{x+0.05f,y-0.75f},false), "Sous-Marin");
        torpilleur = new Shipstate(new Boat(2,new float[]{x+0.05f,y-0.9f},false), "Torpilleur");
    }

    public boolean clickedElem(float inputX, float inputY) {
        if(porteAvion.clickedElem(inputX,inputY)){
            tempBoat=new Boat(porteAvion.boat);
            tempBoatSymbol='5';
            return true;}
        if(croiseur.clickedElem(inputX,inputY)) {
            tempBoat=new Boat(croiseur.boat);
            tempBoatSymbol='4';
            return true;
        }
        if(contreTorpilleur.clickedElem(inputX,inputY)) {
            tempBoat=new Boat(contreTorpilleur.boat);
            tempBoatSymbol='3';
            return true;
        }
        if(sousMarin.clickedElem(inputX,inputY)) {
            tempBoat=new Boat(sousMarin.boat);
            tempBoatSymbol='S';
            return true;
        }
        if(torpilleur.clickedElem(inputX,inputY)) {
            tempBoat=new Boat(torpilleur.boat);
            tempBoatSymbol='2';
            return true;
        }
        return false;
    }

    class Shipstate implements gridElement{
        Shipstate(Boat boat,String name){isPlaced=false;this.boat = boat;this.name=name;}
        boolean isPlaced;
        Boat boat;
        String name;

        public void drawShipstate(GL2 gl){
            if(!isPlaced){boat.drawBoat(gl);}
        }

        public boolean clickedElem(float inputX, float inputY) {
            if(boat.clickedElem(inputX,inputY)) {
                System.out.println(name + " has bin clicked from shipyard.");
                return true;
            }
            return false;
        }
    }

    public void drawShipyard(GL2 gl, TextRenderer renderer){
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.4f,0.4f,0.4f);
        gl.glVertex2f(x,y);
        gl.glVertex2f(x,y-1f);
        gl.glVertex2f(x+.26f,y-1f);
        gl.glVertex2f(x+.26f,y);
        gl.glEnd();

        porteAvion.drawShipstate(gl);
        croiseur.drawShipstate(gl);
        contreTorpilleur.drawShipstate(gl);
        sousMarin.drawShipstate(gl);
        torpilleur.drawShipstate(gl);

    }

    public void placeTempBoat(){
        if(tempBoatSymbol=='5'){
            porteAvion.isPlaced=true;
        } else if (tempBoatSymbol=='4'){
            croiseur.isPlaced=true;
        } else if(tempBoatSymbol=='3'){
            contreTorpilleur.isPlaced=true;
        } else if(tempBoatSymbol=='S'){
            sousMarin.isPlaced=true;
        } else if(tempBoatSymbol=='2'){
            torpilleur.isPlaced=true;
        } else {}
    }

    public void resetBoats(){
        porteAvion.isPlaced=false;
        croiseur.isPlaced=false;
        contreTorpilleur.isPlaced=false;
        sousMarin.isPlaced=false;
        torpilleur.isPlaced=false;

    }

    public boolean areAllShipsPlaced(){
        if(!porteAvion.isPlaced)
            return false;
        if(!croiseur.isPlaced)
            return false;
        if(!contreTorpilleur.isPlaced)
            return false;
        if(!sousMarin.isPlaced)
            return false;
        if(!torpilleur.isPlaced)
            return false;
        return true;
    }

    public boolean isAnyShipPlaced(){
        if(porteAvion.isPlaced||croiseur.isPlaced||contreTorpilleur.isPlaced||sousMarin.isPlaced||torpilleur.isPlaced)
            return true;
        return false;
    }

    public void setBoatsToPlaced(){
        porteAvion.isPlaced=true;
        croiseur.isPlaced=true;
        contreTorpilleur.isPlaced=true;
        sousMarin.isPlaced=true;
        torpilleur.isPlaced=true;
    }

}
