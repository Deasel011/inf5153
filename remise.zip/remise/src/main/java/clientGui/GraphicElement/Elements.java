package clientGui.GraphicElement;

import battleship.domain.*;
import battleship.domain.util.Orientation;
import battleship.encoding.Encoding;
import battleship.opponent.IntelligentOpponent;
import battleship.opponent.RandomOpponent;
import clientGui.Battleship;
import clientGui.SoundElements.MultipleSounds;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;
import battleship.domain.match.Match;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * Created by deasel on 2016-04-13.
 */
public class Elements {
    ArrayList<Torpedo> torpedos;
    ArrayList<Torpedo> opponentTorpedos;
    ArrayList<Torpedo> tempTorpedosList;
    ArrayList<Torpedo> tempOpponentTorpedosList;
    ArrayList<Button> buttons;
    ArrayList<Boat> boats;
    LeftGrid leftGrid;
    RightGrid rightGrid;
    Corporal corporal;
    Shipyard shipyard;
    OpponentAlgorithm algo;
    Match match;
    EndOfMatchPannel panneau;
    TargetedCell playerTarget;
    TargetedCell opponentTarget;
    boolean torpedoLaunching=false;
    boolean isVisualizing=false;
    boolean opponentReady=false;

    String quotes[] = new String[]{"Ghost Rider, this is Strike. We have unknown aircraft inbound Mustang. Your vector zero-nine-zero for bogey.",
            "It’s classified. I could tell you, but then I’d have to kill you.",
            "The defense department regrets to inform you that your sons are dead because they were stupid.",
            "The plaque for the alternates is down in the ladies room.",
            "You don’t have time to think up there. If you think, you’re dead.",
            "You can be my wingman any time.",
            "If you screw up just this much, you’ll be flying a cargo plane full of rubber dog shit out of Hong Kong!",
            "Top Gun rules of engagement are written for your safety and for that of your team. They are not flexible, nor am I. Either obey them or you are history. Is that clear?",
            "Mustang, this is Voodoo 3. Remaining MiGs are bugging out.",
            "How’s it feel to be on the front page of every newspaper in the english-speaking world, even though the other side denies the incident? Congratulations.",
            "Highway to the Danger Zone!"
    };
    String activeQuote;

    Elements(){
        buttons=new ArrayList<Button>();
        boats=new ArrayList<Boat>();
        torpedos=new ArrayList<Torpedo>();
        opponentTorpedos=new ArrayList<Torpedo>();
    }

    public void addCorporal(Corporal corporal){ this.corporal = corporal;}

    public void addShipyard(Shipyard shipyard){ this.shipyard = shipyard;}

    public void addButton(Button button){
        buttons.add(button);
    }

    public void addBoat(Boat boat){
        boats.add(boat);
    }

    public void addTorpedo(Torpedo torpedo){torpedos.add(torpedo);}

    public void addLeftGrid(LeftGrid lgrid){
        leftGrid = lgrid;
    }

    public void addRightGrid(RightGrid rgrid){
        rightGrid = rgrid;
    }

    public void checkClicked(float clickX, float clickY){
        if(clickX!=0.0f&&clickY!=0.0f){

            //BUTTONS
            for (int i = 0; i < buttons.size(); i++) {
                if (buttons.get(i).clickedElem(clickX,clickY)&&buttons.get(i).isAvailable()) {
                    switch(i){
                        case 0://Bouton Quitter
                            shipyard.resetBoats();
                            torpedos.clear();
                            opponentTorpedos.clear();
                            boats.clear();
                            match= Match.createWithDefaultConfig();
                            clearButtons();
                            panneau=null;
                            buttons.get(1).setAvailability(true);
                            buttons.get(2).setAvailability(true);
                            buttons.get(3).setAvailability(true);
                            playerTarget=null;
                            opponentTarget=null;
                            break;
                        case 1://Bouton mystere
                            UIFrame.resetStringCounter();
                            corporal.reset();
                            buttons.get(1).setAvailability(false);
                            corporal.isTalking=true;
                            activeQuote=quotes[(int)(Math.random()*(10))];
                            System.out.println(activeQuote);
                            break;
                        case 2://Bouton nouvelle partie
                                match = Match.createWithDefaultConfig();
                                shipyard.resetBoats();
                                clearButtons();
                                torpedos.clear();
                                opponentTorpedos.clear();
                                boats.clear();
                                leftGrid=new LeftGrid();
                                rightGrid=new RightGrid();
                                buttons.get(7).setAvailability(true);
                                buttons.get(8).setAvailability(true);
                                buttons.get(0).setAvailability(true);
                                buttons.get(11).setAvailability(true);
                                corporal.isTalking = true;
                                activeQuote = "Vous avez debuter une nouvelle escarmouche! Choisissez des navires a gauche ou placer les automatiquements sur la grille de guerre!";
                            break;
                        case 3://Charger partie
                            Encoding decoder = new Encoding();
                            JFileChooser chooser=Battleship.chooseFile();
                            System.out.println(chooser.getSelectedFile());
                            String contents="";
                            try {
                                contents = new String(Files.readAllBytes(Paths.get(chooser.getSelectedFile().toString())));
                            } catch (Exception e){

                            }
                            match=decoder.decode(contents);
                            chargeBoats();
                            chargeTorpedos();
                            chargeRightCells();
                            shipyard.setBoatsToPlaced();
                            shipyard.tempBoat=null;

                            clearButtons();

                            opponentReady=true;
                            buttons.get(0).setAvailability(true);
                            torpedoLaunching=true;

                            break;
                        case 4://Orientation
                            if(shipyard.tempBoat!=null){
                                shipyard.tempBoat.isVertical=(!shipyard.tempBoat.isVertical);
                            }
                            break;
                        case 5://torpille
                            break;
                        case 6://Sauvegarder partie
                            Encoding encoding = new Encoding();
                            int time = (int)System.currentTimeMillis()/1000;
                            String path = System.getProperty("user.dir")+"/savedGames/"+time+".xml";
                            System.out.println(path);
                            try {
                                encoding.encodeToFile(match,path);
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            break;
                        case 7://difficile
                            algo = new IntelligentOpponent(match.getSide1().getOpGrid());
                            match.setAlgo(algo);
                            buttons.get(7).setAvailability(false);
                            buttons.get(8).setAvailability(false);
                            if(shipyard.areAllShipsPlaced())
                                buttons.get(9).setAvailability(true);
                            break;
                        case 8://facile
                            algo = new RandomOpponent(match.getSide1().getOpGrid());
                            match.setAlgo(algo);
                            buttons.get(7).setAvailability(false);
                            buttons.get(8).setAvailability(false);
                            opponentReady=true;
                            if(shipyard.areAllShipsPlaced())
                                buttons.get(9).setAvailability(true);
                            break;
                        case 9://Demarer
                            match.getSide2().getOwnGrid().placeAllShipsRandomly();
                            torpedoLaunching=true;
                            clearButtons();
                            buttons.get(6).setAvailability(true);
                            buttons.get(0).setAvailability(true);
                            opponentReady=true;
                            break;
                        case 10://visualiser
                            clearButtons();
                            buttons.get(0).setAvailability(true);
                            visualisation();
                            isVisualizing=true;
                            panneau=null;
                            break;
                        case 11: //placement automatique
                            match.getSide1().getOwnGrid().placeAllShipsRandomly();
                            boats.clear();
                            chargeBoats();
                            shipyard.setBoatsToPlaced();
                            shipyard.tempBoat=null;
                            if(match.getAlgo()==null){
                                buttons.get(7).setAvailability(true);
                                buttons.get(8).setAvailability(true);
                            } else {
                                buttons.get(9).setAvailability(true);
                            }
                        default:
                            buttons.get(0).setAvailability(true);
                            break;
                    }
                    System.out.println(buttons.get(i).getName() + " has bin clicked.");
                    return;
                }
            }

            //LEFTGRID
            for (int i = 0; i < leftGrid.getCells().size(); i++) {
                if (leftGrid.cells.get(i).clickedElem(clickX, clickY)) {
                    if(shipyard.tempBoat!=null){
                        //askController if boat on position is OK
                        //(if ok) then

                        try {
                            match.getSide1().getOwnGrid()
                                    .shipFromSymbol(shipyard.tempBoatSymbol)
                                    .placeAtCellName(leftGrid.cells.get(i)
                                            .getPosition(), shipyard.tempBoat.isVertical?Orientation.down():Orientation.right());
                            boats.add(new Boat(shipyard.tempBoat.length,leftGrid.cells.get(i).getCellPosition(),shipyard.tempBoat.isVertical));
                            shipyard.placeTempBoat();
                            shipyard.tempBoat=null;
                        } catch (Exception e) {
                            UIFrame.resetStringCounter();
                            corporal.reset();
                            activeQuote="Vos agissements sont indignes     soldat!";
                            corporal.isTalking=true;
                        }

                    }
                    if(boats.size()==5&&!buttons.get(7).isAvailable()&&!buttons.get(2).isAvailable()){
                        buttons.get(9).setAvailability(true);
                    }
                    System.out.println("Left grid: " + leftGrid.cells.get(i).getyAxis() + leftGrid.cells.get(i).getxAxis() + " has bin clicked.");
                    return;
                }
            }

            //RIGHTGRID
            for (int i = 0; i < rightGrid.getCells().size(); i++) {
                if (rightGrid.cells.get(i).clickedElem(clickX, clickY)) {
                    if(torpedoLaunching){
                        if(rightGrid.cells.get(i).isHit){
                            UIFrame.resetStringCounter();
                            corporal.reset();
                            activeQuote="Vous avez deja envoyer une torpille sur cette position soldat!";
                            corporal.isTalking=true;
                        }else {
                            Torpedo launched = null;
                            Torpedo oppTorpedo = null;

                            TorpedoFeedback result = null;
                            torpedoAdds(result, launched,i);
                            System.out.println(result);


                            TorpedoFeedback oppResult = null;
                            opponentTorpedoAdds(oppResult, oppTorpedo, i);
                        }
                    }
                    System.out.println("Right grid: " + rightGrid.cells.get(i).getyAxis() + rightGrid.cells.get(i).getxAxis() + " has bin clicked.");
                    return;
                }
            }

            //SHIPYARD
            if(shipyard.clickedElem(clickX,clickY)){
                buttons.get(4).setAvailability(true);
                shipyard.tempBoat.setPosition(new float[]{-0.70f,-0.82f});
            }
        }
    }


    public void drawButtons(GL2 gl, TextRenderer renderer){
        for(int i=0;i<buttons.size();i++){
            if(buttons.get(i).isAvailable()) {
                buttons.get(i).drawButton(gl, renderer);
            }
        }
    }

    public void drawBoats(GL2 gl){
        for(int i=0;i<boats.size();i++){
            boats.get(i).drawBoat(gl);
        }
    }

    public void drawCorporal(GL2 gl, TextRenderer renderer){
        corporal.drawCorporal(gl,renderer);
    }

    public void drawShipyard(GL2 gl, TextRenderer renderer) {shipyard.drawShipyard(gl, renderer);}

    public void drawTempBoat(GL2 gl) {if(shipyard.tempBoat!= null){shipyard.tempBoat.drawBoat(gl);}}

    public void drawTorpedos(GL2 gl, int counter){
        for(int i=0;i<torpedos.size()&&i<opponentTorpedos.size();i++){
            torpedos.get(i).drawTorpedo(gl, counter);
            opponentTorpedos.get(i).drawTorpedo(gl,counter);
        }
    }

    public void drawTargetedCells(GL2 gl){if(playerTarget!=null)playerTarget.drawTargetCell(gl);
        if(opponentTarget!=null)opponentTarget.drawTargetCell(gl);}

    public void drawPanneau(GL2 gl, TextRenderer renderer){ if(panneau!=null)panneau.drawEndOfMatchPannel(gl,renderer);}

    private int getBoatLength(char sign){
        switch(sign){
            case '2':
                return 2;
            case '3':
                return 3;
            case 'S':
                return 3;
            case '4':
                return 4;
            case '5':
                return 5;
            default:
                return 0;
        }
    }

    public void makeCorporalTalk(String text){
        UIFrame.resetStringCounter();
        corporal.reset();
        activeQuote=text;
        corporal.isTalking=true;
    }

    public void torpedoAdds(TorpedoFeedback result, Torpedo launched,int i) {
        try {
            result = match.getSide1().playAgainstOpponent(rightGrid.cells.get(i).getPosition());
            if(playerTarget==null){
                playerTarget=new TargetedCell(new PositionAdapter(rightGrid,rightGrid.cells.get(i).getPosition()));
            } else {
                playerTarget.changePosition(new PositionAdapter(rightGrid,rightGrid.cells.get(i).getPosition()));
            }
        } catch (MatchDoneException e) {
            matchIsOver();
        } catch (UnplacedShipException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        if (result.isWater()) {
            launched = new Torpedo(false, rightGrid.cells.get(i).getCellPosition());
            MultipleSounds.getWater();
        } else if (result.isTouched()) {
            launched = new Torpedo(true, rightGrid.cells.get(i).getCellPosition());
            MultipleSounds.dropBomb();
            if(result.isSinked()){
                addSinkedShip(result);
            }
        } else if (result.isSinked()){
            launched = new Torpedo(true, rightGrid.cells.get(i).getCellPosition());
            addSinkedShip(result);
            MultipleSounds.dropBomb();
        }

        System.out.println(result);
        torpedos.add(launched);
    }
    public void opponentTorpedoAdds(TorpedoFeedback oppResult, Torpedo oppTorpedo, int i){
        int yAxis=0;
        int xAxis=0;
        try {
            oppResult=match.getSide2().playAgainstOpponentWithAlgo();
            yAxis=oppResult.getCellName().charAt(0)-65;
            if(oppResult.getCellName().substring(1).equals("10")){
                xAxis=9;
            } else {
                xAxis=oppResult.getCellName().charAt(1)-49;
            }

            if(opponentTarget==null){
                opponentTarget=new TargetedCell(new PositionAdapter(leftGrid,oppResult.getCellName()));
            } else {
                opponentTarget.changePosition(new PositionAdapter(leftGrid,oppResult.getCellName()));
            }

        } catch (MatchDoneException e) {
            torpedos.add(new Torpedo(true, rightGrid.cells.get(i).getCellPosition()));
            matchIsOver();
        } catch (UnplacedShipException e) {
            e.printStackTrace();
        }
        if(match.isMatchDone()){
            matchIsOver();
        }
        if (oppResult.isWater()) {
            oppTorpedo = new Torpedo(false, new PositionAdapter(leftGrid, oppResult.getCellName())/*.getPosition(xAxis,yAxis)*/);
        } else if (oppResult.isTouched()) {
            oppTorpedo = new Torpedo(true,  leftGrid.getPosition(xAxis,yAxis));
        } else if(oppResult.isSinked()){
            oppTorpedo = new Torpedo(true,  leftGrid.getPosition(xAxis,yAxis));
        }
        rightGrid.cells.get(i).isHit=true;
        opponentTorpedos.add(oppTorpedo);
    }

    private void chargeTorpedos(){
        TorpedoFeedback plyFeedback=null;
        for(int j=0; j<match.getSide1().getBoard().getOpGrid().getTorpedosPP().size();j++){
            plyFeedback = match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getFeedback();
            if (plyFeedback.isWater()) {
                torpedos.add(new Torpedo(false, rightGrid.getPosition(
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getCol(),
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getRow()
                )));
            } else if (plyFeedback.isTouched()) {
                torpedos.add(new Torpedo(true, rightGrid.getPosition(
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getCol(),
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getRow()
                )));
                if(plyFeedback.isSinked()){
                    addSinkedShip(plyFeedback);
                }
            } else if(plyFeedback.isSinked()){
                torpedos.add(new Torpedo(true, rightGrid.getPosition(
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getCol(),
                        match.getSide1().getBoard().getOpGrid().getTorpedosPP().get(j).getCell().getRow()
                )));
            }
            plyFeedback = match.getSide1().getBoard().getOwnGrid().getTorpedos().get(j).getFeedback();
            Torpedo chargeOppTorpedo=null;
            chargeOpponentTorpedoAdds(plyFeedback,chargeOppTorpedo,j);

        }

    }

    private void chargeBoats(){
        for(int j=0;j<5;j++) {
            boats.add(new Boat(
                    getBoatLength(match.getSide1().getOwnGrid().getShips().get(j).getShipSymbol()),
                    leftGrid.getPosition(
                            match.getSide1().getOwnGrid().getShips().get(j).getCell().getCol(),
                            match.getSide1().getOwnGrid().getShips().get(j).getCell().getRow()),
                    match.getSide1().getOwnGrid().getShips().get(j).getOrientation().isDown()
                            ?true
                            :false));
        }
    }

    private void chargeRightCells(){
        for(int i=0;i<rightGrid.getCells().size();i++){
                rightGrid.getCells().get(i).isHit=match.getSide2().getOwnGrid().cellFromName(rightGrid.getCells().get(i).getPosition()).hasTorpedo();
        }
    }

    private void visualisation(){
        tempTorpedosList=(ArrayList<Torpedo>)torpedos.clone();
        tempOpponentTorpedosList=(ArrayList<Torpedo>)opponentTorpedos.clone();
        isVisualizing=true;
        torpedos.clear();
        opponentTorpedos.clear();
        clearButtons();
    }

    private void clearButtons(){
        for(int i=0;i<buttons.size();i++){
            buttons.get(i).setAvailability(false);
        }
    }

    private void matchIsOver(){
        if (match.getWinner() == match.getSide1()) {
            MultipleSounds.getVictory();
            panneau=new EndOfMatchPannel('r');
            makeCorporalTalk("Félicitation, nous avons remportez la victoire grâce a vous soldat!");
        } else {
            MultipleSounds.youLost();
            panneau=new EndOfMatchPannel('l');
            makeCorporalTalk("Nom d'une pioche soldat... Nous   nous sommes fait massacrés!");
        }
        clearButtons();
        playerTarget=null;
        opponentTarget=null;
        buttons.get(10).setAvailability(true);
        buttons.get(0).setAvailability(true);
        opponentReady=false;
        torpedoLaunching = false;
    }

    public void chargeOpponentTorpedoAdds(TorpedoFeedback oppResult, Torpedo oppTorpedo, int i){
        int yAxis=0;
        int xAxis=0;
            yAxis=oppResult.getCellName().charAt(0)-65;
            if(oppResult.getCellName().substring(1).equals("10")){
                xAxis=9;
            } else {
                xAxis=oppResult.getCellName().charAt(1)-49;
            }
        if (oppResult.isWater()) {
            oppTorpedo = new Torpedo(false, leftGrid.getPosition(xAxis,yAxis));
        } else if (oppResult.isTouched()) {
            oppTorpedo = new Torpedo(true,  leftGrid.getPosition(xAxis,yAxis));
        } else if(oppResult.isSinked()){
            oppTorpedo = new Torpedo(true,  leftGrid.getPosition(xAxis,yAxis));
        }
        rightGrid.cells.get(i).isHit=true;
        opponentTorpedos.add(oppTorpedo);
    }
    public void addSinkedShip(TorpedoFeedback result){
        int length=0;
        boolean isVertical=true;
        switch(result.getShipIdent()){
            case 2:
                length=2;
                isVertical=(match.getSide2().getOwnGrid().shipFromSymbol('2').getOrientation().getName().equals("right"))?false:true;
                break;
            case 3:
                length=3;
                isVertical=(match.getSide2().getOwnGrid().shipFromSymbol('3').getOrientation().getName().equals("right"))?false:true;
                break;
            case 4:
                length=4;
                isVertical=(match.getSide2().getOwnGrid().shipFromSymbol('4').getOrientation().getName().equals("right"))?false:true;
                break;
            case 5:
                length=5;
                isVertical=(match.getSide2().getOwnGrid().shipFromSymbol('5').getOrientation().getName().equals("right"))?false:true;
                break;
            default:
                length=3;
                isVertical=(match.getSide2().getOwnGrid().shipFromSymbol('S').getOrientation().getName().equals("right"))?false:true;
                break;
        }
        boats.add(new Boat(length,new PositionAdapter(rightGrid,result.getShipCellName()),isVertical));
    }
}
