package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

import java.util.ArrayList;

public class LeftGrid extends Grid implements gridElement {
    int iterator;
    LeftGrid() {
        x=-0.675f;
        y=0.20f;
        initCells();
    }
    public void drawLeftGrid(GL2 gl, TextRenderer renderer){


        float xs = -0.75f;
        float ys = -0.85f;
        //Background
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0,100,100);
        gl.glVertex2f(-0.70f,-0.75f);
        gl.glVertex2f(-0.70f,0.25f);
        gl.glVertex2f(-0.20f,0.25f);
        gl.glVertex2f(-0.20f,-0.75f);
        gl.glEnd();
        //Vertices
        gl.glColor3f(100,100,100);
        for(iterator=0;iterator<=10;iterator++){
            xs=xs+0.05f;
            gl.glBegin (GL2.GL_LINES);//static field
            gl.glVertex2f(xs,0.25f);
            gl.glVertex2f(xs,-0.75f);
            gl.glEnd();
        }
        for(iterator=0;iterator<=10;iterator++){
            ys=ys+0.10f;
            gl.glBegin (GL2.GL_LINES);//static field
            gl.glVertex2f(-0.20f,ys);
            gl.glVertex2f(-0.70f,ys);
            gl.glEnd();
        }

        //Col & Li
        char carac = 'A';
        for (iterator = 0; iterator < 10; iterator++) {
            String car = ""+(carac++);
            renderer.beginRendering(1600, 800);
            // optionally set the color
            renderer.setColor(1.0f, 0.2f, 0.2f, 0.8f);
            renderer.draw(car, 220, 470-(40*iterator));
            // ... more draw commands, color changes, etc.
            renderer.endRendering();
        }
        int num = 1;
        for (iterator = 0; iterator < 10; iterator++) {
            String car = ""+(num++);
            renderer.beginRendering(1600, 800);
            // optionally set the color
            renderer.setColor(1.0f, 0.2f, 0.2f, 0.8f);
            renderer.draw(car, 970+(40*iterator), 510);
            // ... more draw commands, color changes, etc.
            renderer.endRendering();
        }
    }

    ArrayList<Cell> getCells(){
        return this.cells;
    }

    public boolean clickedElem(float inputX, float inputY) {
        return false;
    }
}
