package clientGui.GraphicElement;

import battleship.domain.TorpedoFeedback;

/**
 * Created by Philippe on 2016-04-28.
 */
public class PositionAdapter extends Position {
    PositionAdapter(Grid grid, int indexX, int indexY){
        position=grid.getPosition(indexX,indexY);
    }

    PositionAdapter(Grid grid, String cellName){
        int indexX,indexY;
        if(cellName.substring(1).equals("10")){indexX=9;}
        else {indexX=cellName.charAt(1)-49;};
        indexY=cellName.charAt(0)-65;
        position=grid.getPosition(indexX,indexY);
    }

    PositionAdapter(Grid grid, TorpedoFeedback feedback){
        int indexX,indexY;
        String cellName = feedback.getCellName();
        if(cellName.substring(1).equals("10")){indexX=9;}
        else {indexX=cellName.charAt(1)-49;};
        indexY=cellName.charAt(0)-65;
        position=grid.getPosition(indexX,indexY);
    }
}
