package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;

/**
 * Created by Philippe on 2016-04-28.
 */
class Boat implements gridElement{
    boolean isVertical;
    float [] position;
    int length;
    float lowerX;
    float upperX;
    float lowerY;
    float upperY;

    Boat(int length, float[] position, boolean isVertical){
        this.isVertical=isVertical;
        this.position=position;
        this.length=length;

        if(this.isVertical){
            lowerX=position[0];
            upperY=position[1]+0.03f;
            upperX=position[0]+0.02f;
            lowerX=position[0]-(0.17f+((length-2)*0.10f));
        } else {
            lowerX=position[0];
            upperY=position[1]+0.04f;
            upperX=position[0]+0.085f+((length-2)*0.05f);
            lowerY=position[1]-0.04f;
        }
    }
    Boat(int length, Position position, boolean isVertical){
        this.isVertical=isVertical;
        this.position=position.position;
        this.length=length;

        if(this.isVertical){
            lowerX=this.position[0];
            upperY=this.position[1]+0.03f;
            upperX=this.position[0]+0.02f;
            lowerX=this.position[0]-(0.17f+((length-2)*0.10f));
        } else {
            lowerX=this.position[0];
            upperY=this.position[1]+0.04f;
            upperX=this.position[0]+0.085f+((length-2)*0.05f);
            lowerY=this.position[1]-0.04f;
        }
    }

    Boat(Boat other){
        this.isVertical=other.isVertical;
        this.length=other.length;
        this.position = new float[]{other.position[0],other.position[1]};

        if(this.isVertical){
            lowerX=position[0];
            upperY=position[1]+0.03f;
            upperX=position[0]+0.02f;
            lowerX=position[0]-(0.17f+((length-2)*0.10f));
        } else {
            lowerX=position[0];
            upperY=position[1]+0.04f;
            upperX=position[0]+0.085f+((length-2)*0.05f);
            lowerY=position[1]-0.04f;
        }
    }

    public void setPosition(float [] position){
        this.position=position;

        if(this.isVertical){
            lowerX=position[0];
            upperY=position[1]+0.03f;
            upperX=position[0]+0.02f;
            lowerX=position[0]-(0.17f+((length-2)*0.10f));
        } else {
            lowerX=position[0];
            upperY=position[1]+0.04f;
            upperX=position[0]+0.085f+((length-2)*0.05f);
            lowerY=position[1]-0.04f;
        }
    }



    public void drawBoat(GL2 gl){
        if(isVertical){
            drawVerticalBoat(gl);
        }
        else {
            drawHorizontalBoat(gl);
        }
    }
    public void drawVerticalBoat(GL2 gl){
        gl.glColor3f(0.50f,0.50f,0.50f);
        //le frame du bateau vertical en 2d
        float x = position[0];
        float y = position[1]+0.03f;
        gl.glBegin(GL2.GL_POLYGON);
        gl.glVertex2f(x,y);
        gl.glVertex2f(x+0.01f,y-0.02f);
        gl.glVertex2f(x+0.02f,y-0.075f);
        float mod = (length-2)*0.10f;
        gl.glVertex2f(x+0.02f,y-(0.17f+mod));
        gl.glVertex2f(x-0.02f,y-(0.17f+mod));
        gl.glVertex2f(x-0.02f,y-0.075f);
        gl.glVertex2f(x-0.01f,y-0.02f);
        gl.glEnd();

        //cheminées
        gl.glColor3f(1,1,1);
    }
    private void drawChimney(float [] position, GL2 gl){

    }
    public void drawHorizontalBoat(GL2 gl){
        gl.glColor3f(0.50f,0.50f,0.50f);
        //le frame du bateau horizontal en 2d
        float x = position[0]-0.015f;
        float y = position[1];
        gl.glBegin(GL2.GL_POLYGON);
        gl.glVertex2f(x,y);
        gl.glVertex2f(x+0.01f,y-0.02f);
        gl.glVertex2f(x+0.0325f,y-0.04f);
        float mod = (length-2)*0.05f;
        gl.glVertex2f(x+(0.085f+mod),y-0.04f);
        gl.glVertex2f(x+(0.085f+mod),y+0.04f);
        gl.glVertex2f(x+0.0325f,y+0.04f);
        gl.glVertex2f(x+0.01f,y+0.02f);
        gl.glEnd();

        //cheminées
        gl.glColor3f(1,1,1);
    }

    public boolean clickedElem(float inputX, float inputY) {
        if(inputX<=upperX&&inputX>=lowerX&&inputY<=upperY&&inputY>=lowerY){
            return true;
        } else {
            return false;
        }
    }
}
