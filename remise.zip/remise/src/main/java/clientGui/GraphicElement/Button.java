package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

/**
 * Created by Philippe on 2016-04-12.
 */
public class Button implements gridElement {
    ButtonState state;
    String buttonName;
    float upperX;
    float lowerX;
    float upperY;
    float lowerY; //upper X, lower X, upper Y, lower Y
    int[] iPosition;

    Button(String text, float[] position) {
        buttonName = text;
        upperX=position[0]+.1f;
        lowerX=position[0]-.03f;
        upperY=position[1]+.05f;
        lowerY=position[1]-0.02f;
        state=new ButtonState();
        iPosition= new int [2];
        iPosition[0]=800+(int)(800*position[0]);
        iPosition[1]=400+(int)(400*position[1]);

    }
    public void drawButton(GL2 gl,TextRenderer renderer){

        if(!state.available){return;}

        //Button Background
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.5f,0.5f,0.55f);
        gl.glVertex2f(lowerX,lowerY);
        gl.glVertex2f(lowerX,upperY);
        gl.glVertex2f(upperX,upperY);
        gl.glVertex2f(upperX,lowerY);
        gl.glEnd();
        //Button Outline
        gl.glBegin(GL2.GL_LINES);
        gl.glColor3f(1f,1f,1f);
        gl.glVertex2f(lowerX,lowerY);
        gl.glVertex2f(lowerX,upperY);
        gl.glVertex2f(upperX,upperY);
        gl.glVertex2f(upperX,lowerY);
        gl.glVertex2f(lowerX,upperY);
        gl.glVertex2f(upperX,upperY);
        gl.glVertex2f(lowerX,lowerY);
        gl.glVertex2f(upperX,lowerY);
        gl.glEnd();

        //Button Text
        renderer.beginRendering(1600, 800);
        // optionallowerY set the color
        renderer.setColor(1.0f, 0.2f, 0.2f, 0.8f);
        renderer.draw(buttonName,iPosition[0],iPosition[1]);
        // ... more draw commands, color changes, etc.
        renderer.endRendering();
    }

    public String getName(){
        return buttonName;
    }

    public boolean clickedElem(float inputX, float inputY) {
        if(inputX<=upperX&&inputX>=lowerX&&inputY<=upperY&&inputY>=lowerY){
            return true;
        } else {
            return false;
        }
    }

    public boolean isAvailable(){
        return state.available;
    }

    public void setAvailability(boolean value){
        state.available=value;
    }

    private class ButtonState{
        boolean isClicked;
        boolean available;
        ButtonState(){
            isClicked = false;
            available = true;
        }
    }


}
