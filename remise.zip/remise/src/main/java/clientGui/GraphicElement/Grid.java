package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;

import java.util.ArrayList;

public class Grid implements gridElement {
    float x=0f;
    float y=0f;
    ArrayList<Cell> cells;

    public void drawTestDot(GL2 gl){
        gl.glBegin(GL2.GL_POLYGON);
        gl.glVertex2f(x-0.005f,y-0.01f);
        gl.glVertex2f(x+0.005f,y-0.01f);
        gl.glVertex2f(x+0.005f,y+0.01f);
        gl.glVertex2f(x-0.005f,y+0.01f);
        gl.glEnd();
    };

    public float[] getPosition(int indexX, int indexY){
        float [] position = new float[2];
        position[0]=x+0.05f*indexX;
        position[1]=y-0.10f*indexY;
        return position;
    };

    public float getXPosition(int indexX){
        return x+0.05f*indexX;
    }

    public float getYPosition(int indexY){
        return y-0.10f*indexY;
    }

    public boolean clickedElem(float inputX, float inputY) {
        return false;
    }

    public void initCells(){
        cells=new ArrayList<Cell>();
        for(int i=0;i<10;i++){
            for(int j=0;j<10;j++){
                float[] position = getPosition(i,j);
                cells.add(new Cell(position[0]-0.0249f,position[0]+0.0249f,position[1]-0.0499f,position[1]+0.0499f, 1+i, (char)('A'+j)));
            }
        }
    }

    //TODO finir le constructeur de cell puis dans le constructeur de grille, créer les cells aux endroits appropriés
    class Cell implements gridElement{
        boolean isHit;
        char yAxis;
        int xAxis;
        float lowerX;
        float upperX;
        float lowerY;
        float upperY;
        Cell(float lX, float uX, float lY, float uY, int xAxis, char yAxis){
            this.xAxis=xAxis;
            this.yAxis=yAxis;
            lowerX=lX;
            lowerY=lY;
            upperX=uX;
            upperY=uY;
            isHit=false;
        }
        public String getPosition(){
            return ""+yAxis+xAxis;
        }

        public float[] getCellPosition(){
            return new float[] {lowerX+0.025f,lowerY+0.05f};
        }

        public char getyAxis(){
            return yAxis;
        }

        public int getxAxis(){
            return xAxis;
        }

        public boolean clickedElem(float inputX, float inputY) {
            if(inputX<=upperX&&inputX>=lowerX&&inputY<=upperY&&inputY>=lowerY){
                return true;
            } else {
                return false;
            }
        }
    }
}
