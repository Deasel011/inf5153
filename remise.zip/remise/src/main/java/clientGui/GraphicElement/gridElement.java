package clientGui.GraphicElement;

/**
 * Created by Philippe on 2016-04-12.
 */
public interface gridElement {
    boolean clickedElem(float inputX, float inputY);
    /*
    boolean clickedElem(float inputX, float inputY){
        if(inputX<=upperX&&inputX>=lowerX&&inputY<=upperY&&inputY>=lowerY){
        return true;
        } else {
        return false;
        }
    }
     */
}
