package clientGui.GraphicElement;

/**
 * Created by Philippe on 2016-04-28.
 */
public class Position {
    float [] position;
    Position(){
        position=new float[2];
    }
    Position(float x, float y){
        position=new float[]{x,y};
    }
    Position(Position other){
        position=new float[2];
        position[0]=other.getX();
        position[1]=other.getY();
    }
    public float getX(){
        assert(position.length==2);
        return position[0];
    }
    public float getY(){
        assert(position.length==2);
        return position[1];
    }
}
