package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;

/**
 * Created by Philippe on 2016-04-28.
 */
class Torpedo implements gridElement{
    boolean isHit;
    float radius_min;
    float radius;
    float radiusOffset;
    float[] position;

    Torpedo(boolean isHit, float[] position){
        this.isHit=isHit;
        radius_min = 0.005f;
        this.position = position;
    }

    Torpedo(boolean isHit, Position position){
        this.isHit=isHit;
        radius_min = 0.005f;
        this.position = new float[2];
        this.position[0]=position.getX();
        this.position[1]=position.getY();
    }

    public void drawTorpedo(GL2 gl, int counter){
        int i;
        float x = position[0];
        float y = position[1];
        float twicePi = (float) (2.0f * Math.PI);
        if(isHit){
            radius=0.04f;
            gl.glBegin(GL2.GL_POLYGON);
            gl.glColor3f(1,1,0);
            for(i=0;i<16;i++){
                if(i%4==0)gl.glVertex2f((float)(x+(radius*Math.cos(i*twicePi/16*(counter%16+1)))/2),(float)(y+(radius*Math.sin(i*twicePi/16*(counter%16+1)))));
                else if(i%3==0) gl.glVertex2f((float)(x+((radius-0.015f)*Math.cos(i*twicePi/16*(counter%16)))/2),(float)(y+((radius-0.015f)*Math.sin(i*twicePi/16*(counter%16)))));
            }
            gl.glEnd();
            radius=0.025f;
            gl.glBegin(GL2.GL_POLYGON);
            gl.glColor3f(1,0,0);
            for(i=0;i<8;i++){
                if(i%2==0)gl.glVertex2f((float)(x+(radius*Math.cos(i*twicePi/8*(counter%8)))/2),(float)(y+(radius*Math.sin(i*twicePi/8*(counter%8)))));
                else gl.glVertex2f((float)(x+((radius-0.015f)*Math.cos(i*twicePi/8*(counter%8)))/2),(float)(y+((radius-0.015f)*Math.sin(i*twicePi/8*(counter%8)))));
            }
            gl.glEnd();

            radius=0.015f;
            gl.glBegin(GL2.GL_POLYGON);
            gl.glColor3f(1,0.7f,0);
            for(i=0;i<5;i++){
                if(i%2==0)gl.glVertex2f((float)(x+(radius*Math.cos(i*twicePi/5*(counter%5)))/2),(float)(y+(radius*Math.sin(i*twicePi/5*(counter%5)))));
                else gl.glVertex2f((float)(x+((radius-0.015f)*Math.cos(i*twicePi/5*(counter%5)))/2),(float)(y+((radius-0.015f)*Math.sin(i*twicePi/5*(counter%5)))));
            }
            gl.glEnd();
        } else {
            //counter=counter%5;
            radius=radius_min*(counter%8);
            int lineAmount = 100;
            gl.glBegin(GL2.GL_LINE_LOOP);
            gl.glColor3f(0f,0f,1f);
            for(i=0;i<lineAmount;i++){
                gl.glVertex2f((float)(x+(radius*Math.cos(i*twicePi/lineAmount))/2),(float)(y+(radius*Math.sin(i*twicePi/lineAmount))));
            }
            gl.glEnd();

            //counter=counter%5;
            radiusOffset=radius_min*((counter+4)%8);
            gl.glBegin(GL2.GL_LINE_LOOP);
            for(i=0;i<lineAmount;i++){
                gl.glVertex2f((float)(x+(radiusOffset*Math.cos(i*twicePi/lineAmount))/2),(float)(y+(radiusOffset*Math.sin(i*twicePi/lineAmount))));
            }
            gl.glEnd();
        }
    }

    public boolean clickedElem(float inputX, float inputY) {
        return false;
    }
}
