package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

/**
 * Created by Philippe on 2016-04-28.
 */
class GameBackground{
    public static void drawGameBackground(GL2 gl, TextRenderer renderer){
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.75f, 0.75f, 0.75f);
        gl.glVertex2f(1f,1f);
        gl.glVertex2f(-1f,1f);
        gl.glVertex2f(-1f,-1f);
        gl.glVertex2f(1f,-1f);
        gl.glEnd();
    }

}
