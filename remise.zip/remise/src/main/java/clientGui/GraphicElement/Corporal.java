package clientGui.GraphicElement;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.awt.TextRenderer;

/**
 * Created by deasel on 2016-04-19.
 */
public class Corporal {
    boolean isTalking;
    boolean mouthOpened;
    float [] position;
    String say;
    String say2;
    String say3;
    String say4;
    String say5;

    Corporal(){
        isTalking=false;
        mouthOpened=false;
        position = new float[] {0.0f,0.0f};
        say="";
        say2="";
        say3="";
        say4="";
        say5="";

    }

    public void reset(){
        isTalking=false;
        mouthOpened=false;
        say="";
        say2="";
        say3="";
        say4="";
        say5="";
    }

    public void corporalSays(String text, int counter){
        int max=text.length()*6;
        if(counter/5<=text.length()) {
            say = text.substring(0, counter / 5);
        }
        if(counter%5==0){mouthOpened=(!mouthOpened);}
        if (counter==max){
            isTalking=false;
            say="";
            say2="";
            say3="";
            say4="";
            say5="";
            mouthOpened=false;
        }
    }

    public void drawCorporal(GL2 gl, TextRenderer renderer){
        float x=position[0];
        float y=position[1];

        //Background noir du general
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.0f,0.0f,0.0f);
        gl.glVertex2f(x-.199f,y+.2501f);
        gl.glVertex2f(x+.199f,y+.2501f);
        gl.glVertex2f(x+.199f,y-.75f);
        gl.glVertex2f(x-.199f,y-.75f);
        gl.glEnd();

        //Veston vert du general/caporal what ever...
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.05f,0.2f,0.02f);
        gl.glVertex2f(x-.1499f,y-.1f);
        gl.glVertex2f(x-.08f,y-0.05f);
        gl.glVertex2f(x+.08f,y-0.05f);
        gl.glVertex2f(x+.1499f,y-.1f);
        gl.glVertex2f(x+.1499f,y-.40f);
        gl.glVertex2f(x-.1499f,y-.40f);
        gl.glEnd();

        //frame de tete du général
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.65f,0.5f,0.39f);
        gl.glVertex2f(x-.07f,y+.15f);
        gl.glVertex2f(x-.07f,y-.015f);
        gl.glVertex2f(x-.06f,y-.025f);
        gl.glVertex2f(x+.06f,y-.025f);
        gl.glVertex2f(x+.07f,y-.015f);
        gl.glVertex2f(x+.07f,y+.15f);
        gl.glEnd();

        //yeux du general
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(1f,1f,1f);
        gl.glVertex2f(x-.05f,y+.09f);
        gl.glVertex2f(x-.02f,y+.07f);
        gl.glVertex2f(x-.05f,y+.06f);
        gl.glEnd();
        gl.glBegin(GL2.GL_POLYGON);
        gl.glVertex2f(x+.05f,y+.09f);
        gl.glVertex2f(x+.02f,y+.07f);
        gl.glVertex2f(x+.05f,y+.06f);
        gl.glEnd();
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0f,0f,0f);
        gl.glVertex2f(x+.03f,y+.076f);
        gl.glVertex2f(x+.02f,y+.07f);
        gl.glVertex2f(x+.03f,y+.065f);
        gl.glEnd();
        gl.glBegin(GL2.GL_POLYGON);
        gl.glVertex2f(x-.03f,y+.076f);
        gl.glVertex2f(x-.02f,y+.07f);
        gl.glVertex2f(x-.03f,y+.065f);
        gl.glEnd();

        //cheveux du général
        gl.glBegin(GL2.GL_POLYGON);
        gl.glColor3f(0.93f,0.81f,0.63f);
        gl.glVertex2f(x-.070f,y+.17f);
        gl.glVertex2f(x-.076f,y+.10f);
        gl.glVertex2f(x-.04f,y+.13f);
        gl.glVertex2f(x+.04f,y+.13f);
        gl.glVertex2f(x+.076f,y+.10f);
        gl.glVertex2f(x+.062f,y+.20f);
        gl.glEnd();

        //étoile du général
        float starX=x-0.1f;
        float starY=y-0.2f;
        gl.glColor3f(0.93f,0.67f,0.05f);
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex2f(starX,starY);//P1
        gl.glVertex2f(starX+0.0245f,starY-0.07f);//P4
        gl.glVertex2f(starX-0.035f,starY-0.105f);//P7
        gl.glEnd();
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex2f(starX-0.045f,starY-0.035f);//P9
        gl.glVertex2f(starX+0.045f,starY-0.035f);//P3
        gl.glVertex2f(starX,starY-0.085f);//P6
        gl.glEnd();
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex2f(starX-0.0245f,starY-0.07f);//P8
        gl.glVertex2f(starX,starY);//P1
        gl.glVertex2f(starX+0.035f,starY-0.105f);//P5
        gl.glEnd();

        //médailles du général


        //nez du general

        //machoire du general
        if(this.mouthOpened){
            float openedY=y-0.03f;
            gl.glBegin(GL2.GL_POLYGON);
            gl.glColor3f(0.65f,0.5f,0.39f);
            gl.glVertex2f(x,openedY-.025f);
            gl.glVertex2f(x-.07f,openedY);
            gl.glVertex2f(x-.07f,openedY-.065f);
            gl.glVertex2f(x-.06f,openedY-.075f);
            gl.glVertex2f(x+.06f,openedY-.075f);
            gl.glVertex2f(x+.07f,openedY-.065f);
            gl.glVertex2f(x+.07f,openedY);
            gl.glEnd();
        } else {
            gl.glBegin(GL2.GL_POLYGON);
            gl.glColor3f(0.65f,0.5f,0.39f);
            gl.glVertex2f(x,y-.025f);
            gl.glVertex2f(x-.07f,y);
            gl.glVertex2f(x-.07f,y-.065f);
            gl.glVertex2f(x-.06f,y-.075f);
            gl.glVertex2f(x+.06f,y-.075f);
            gl.glVertex2f(x+.07f,y-.065f);
            gl.glVertex2f(x+.07f,y);
            gl.glEnd();
        }

        //Texte du general
        if(say.length()>34){
            say2=say.substring(34);
            say=say.substring(0,34);
            if(say2.length()>35){say3=say2.substring(34);say2=say2.substring(0,34);}
            if(say3.length()>35){say4=say3.substring(34);say3=say3.substring(0,34);}
            if(say4.length()>35){say5=say4.substring(34);say4=say4.substring(0,34);}
        }
        renderer.beginRendering(1600, 800);
        // optionallowerY set the color
        renderer.setColor(1.0f, 0.2f, 0.2f, 0.8f);
        renderer.draw(say,650,210);
        renderer.draw(say2,650,190);
        renderer.draw(say3,650,170);
        renderer.draw(say4,650,150);
        renderer.draw(say5,650,130);
        // ... more draw commands, color changes, etc.
        renderer.endRendering();

    }
}
