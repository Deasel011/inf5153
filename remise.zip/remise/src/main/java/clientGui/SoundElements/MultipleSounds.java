package clientGui.SoundElements;
/**
 * Inspiré du code fournit par jogamp pour des sources de son multiples.
 */

import java.nio.ByteBuffer;

import com.jogamp.openal.AL;
import com.jogamp.openal.ALFactory;
import com.jogamp.openal.util.ALut;

public class MultipleSounds {

    static AL al;

    // Maximum number of buffers we will need.
    static final int NUM_BUFFERS = 5;

    // Maximum emissions we will need.
    static final int NUM_SOURCES = 5;

    // These index the buffers and sources
    static final int MUSIC = 0;
    static final int BOMB   = 1;
    static final int WATER   = 2;
    static final int TRUMPET   = 3;
    static final int LOSING   = 4;


    // Buffers hold sound data
    static int[] buffers = new int[NUM_BUFFERS];

    // Sources are points of emitting sound
    static int[] sources = new int[NUM_SOURCES];

    // Position of the source sounds.
    static float[][] sourcePos = new float[NUM_SOURCES][3];

    // Velocity of the source sounds
    static float[][] sourceVel = new float[NUM_SOURCES][3];

    // Position of the listener.
    static float[] listenerPos = { 0.0f, 0.0f, 0.0f };

    // Velocity of the listener.
    static float[] listenerVel = { 0.0f, 0.0f, 0.0f };

    // Orientation of the listener. (first 3 elements are "at", second 3 are "up")
    static float[] listenerOri = { 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f };
    static int loadALData() {

        //variables to load into

        int[] format = new int[1];
        int[] size = new int[1];
        ByteBuffer[] data = new ByteBuffer[1];
        int[] freq = new int[1];
        int[] loop = new int[1];

        // load wav data into buffers

        al.alGenBuffers(NUM_BUFFERS, buffers, 0);
        if (al.alGetError() != AL.AL_NO_ERROR) {
            return AL.AL_FALSE;
        }

        ALut.alutLoadWAVFile(
                "src/sounds/anthem.wav",
                format,
                data,
                size,
                freq,
                loop);
        al.alBufferData(
                buffers[MUSIC],
                format[0],
                data[0],
                size[0],
                freq[0]);


        ALut.alutLoadWAVFile(
                "src/sounds/bomb.wav",
                format,
                data,
                size,
                freq,
                loop);
        al.alBufferData(
                buffers[BOMB],
                format[0],
                data[0],
                size[0],
                freq[0]);


        ALut.alutLoadWAVFile(
                "src/sounds/water.wav",
                format,
                data,
                size,
                freq,
                loop);
        al.alBufferData(
                buffers[WATER],
                format[0],
                data[0],
                size[0],
                freq[0]);

        ALut.alutLoadWAVFile(
                "src/sounds/trumpet.wav",
                format,
                data,
                size,
                freq,
                loop);
        al.alBufferData(
                buffers[TRUMPET],
                format[0],
                data[0],
                size[0],
                freq[0]);

        ALut.alutLoadWAVFile(
                "src/sounds/looser.wav",
                format,
                data,
                size,
                freq,
                loop);
        al.alBufferData(
                buffers[LOSING],
                format[0],
                data[0],
                size[0],
                freq[0]);

        // bind buffers into audio sources
        al.alGenSources(NUM_SOURCES, sources, 0);

        al.alSourcei(sources[MUSIC], AL.AL_BUFFER, buffers[MUSIC]);
        al.alSourcef(sources[MUSIC], AL.AL_PITCH, 1.0f);
        al.alSourcef(sources[MUSIC], AL.AL_GAIN, 1.0f);
        al.alSourcefv(sources[MUSIC], AL.AL_POSITION, sourcePos[MUSIC], 0);
        al.alSourcefv(sources[MUSIC], AL.AL_POSITION, sourceVel[MUSIC], 0);
        al.alSourcei(sources[MUSIC], AL.AL_LOOPING, AL.AL_TRUE);

        al.alSourcei(sources[BOMB], AL.AL_BUFFER, buffers[BOMB]);
        al.alSourcef(sources[BOMB], AL.AL_PITCH, 1.0f);
        al.alSourcef(sources[BOMB], AL.AL_GAIN, 1.0f);
        al.alSourcefv(sources[BOMB], AL.AL_POSITION, sourcePos[BOMB], 0);
        al.alSourcefv(sources[BOMB], AL.AL_POSITION, sourceVel[BOMB], 0);
        al.alSourcei(sources[BOMB], AL.AL_LOOPING, AL.AL_FALSE);

        al.alSourcei(sources[WATER], AL.AL_BUFFER, buffers[WATER]);
        al.alSourcef(sources[WATER], AL.AL_PITCH, 1.0f);
        al.alSourcef(sources[WATER], AL.AL_GAIN, 1.0f);
        al.alSourcefv(sources[WATER], AL.AL_POSITION, sourcePos[WATER], 0);
        al.alSourcefv(sources[WATER], AL.AL_POSITION, sourceVel[WATER], 0);
        al.alSourcei(sources[WATER], AL.AL_LOOPING, AL.AL_FALSE);


        al.alSourcei(sources[TRUMPET], AL.AL_BUFFER, buffers[TRUMPET]);
        al.alSourcef(sources[TRUMPET], AL.AL_PITCH, 1.0f);
        al.alSourcef(sources[TRUMPET], AL.AL_GAIN, 1.0f);
        al.alSourcefv(sources[TRUMPET], AL.AL_POSITION, sourcePos[TRUMPET], 0);
        al.alSourcefv(sources[TRUMPET], AL.AL_POSITION, sourceVel[TRUMPET], 0);
        al.alSourcei(sources[TRUMPET], AL.AL_LOOPING, AL.AL_FALSE);

        al.alSourcei(sources[LOSING], AL.AL_BUFFER, buffers[LOSING]);
        al.alSourcef(sources[LOSING], AL.AL_PITCH, 1.0f);
        al.alSourcef(sources[LOSING], AL.AL_GAIN, 1.0f);
        al.alSourcefv(sources[LOSING], AL.AL_POSITION, sourcePos[LOSING], 0);
        al.alSourcefv(sources[LOSING], AL.AL_POSITION, sourceVel[LOSING], 0);
        al.alSourcei(sources[LOSING], AL.AL_LOOPING, AL.AL_FALSE);

        // do another error check and return
        if (al.alGetError() != AL.AL_NO_ERROR) {
            return AL.AL_FALSE;
        }

        return AL.AL_TRUE;
    }
    static void setListenerValues() {
        al.alListenerfv(AL.AL_POSITION, listenerPos, 0);
        al.alListenerfv(AL.AL_VELOCITY, listenerVel, 0);
        al.alListenerfv(AL.AL_ORIENTATION, listenerOri, 0);
    }

    public static void killAllData() {
        al.alDeleteBuffers(NUM_BUFFERS, buffers, 0);
        al.alDeleteSources(NUM_SOURCES, sources, 0);
        ALut.alutExit();
    }
    public static void playSound() {
        al = ALFactory.getAL();

        // Initialize OpenAL and clear the error bit

        ALut.alutInit();
        al.alGetError();

        // Load the wav data.

        if(loadALData() == AL.AL_FALSE) {
            System.exit(1);
        }
        setListenerValues();

        // begin the MUSIC sample to play

        al.alSourcePlay(sources[MUSIC]);
    }
    public static void dropBomb(){
        al.alSourcePlay(sources[BOMB]);
    }

    public static void getWater(){
        al.alSourcePlay(sources[WATER]);
    }

    public static void getVictory(){
        al.alSourcePlay(sources[TRUMPET]);
    }

    public static void youLost(){
        al.alSourceStop(sources[WATER]);
        al.alSourceStop(sources[BOMB]);
        al.alSourcePlay(sources[LOSING]);
    }
}