package clientGui;

import clientGui.GraphicElement.UIFrame;
import clientGui.SoundElements.MultipleSounds;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.FPSAnimator;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/**
 * Created by deasel on 2016-04-19.
 */
public class Battleship {
    static GLCanvas canvas;

    public static void main(String [] args){
        startAnimator();
        MultipleSounds.playSound();
    }
    public static JFileChooser chooseFile(){
        JFileChooser chooser=new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "XML document", "xml");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(canvas);
        if(returnVal == JFileChooser.APPROVE_OPTION){
            System.out.println("You choose to open this file: "+ chooser.getSelectedFile().getName());
        }
        return chooser;
    }

    public static void startAnimator(){
        GLProfile glp = GLProfile.getDefault();
        GLCapabilities caps = new GLCapabilities(glp);
        canvas = new GLCanvas(caps);
        UIFrame uiframe=new UIFrame();
        canvas.addMouseListener(uiframe);
        canvas.addGLEventListener(uiframe);
        canvas.setSize(1600,800);

        Frame frame = new Frame("Battleship");
        frame.setSize(1600, 800);
        frame.add(canvas);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                MultipleSounds.killAllData();
                System.exit(0);
            }
        });

        FPSAnimator animator = new FPSAnimator(canvas, 60);
        animator.start();
    }

}
