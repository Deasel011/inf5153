package battleship.opponent;

import battleship.domain.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;

import java.util.List;

import battleship.domain.Cell;

public class RandomOpponent extends OpponentAlgorithm {

	public RandomOpponent(OpponentGrid opGrid) {
		super(opGrid);
	}
	
	public boolean encodingEqualsCustom(RandomOpponent other) {
		return (
			opGrid.encodingEquals(other.opGrid) && 
			getName().equals(other.getName())
		);
	}
	
	public String getName() {
		return "random";
	}
	
	public CellList<OpponentCell> getNextCells() {
		return getOpGrid().getCellsPP().filter(cell -> cell.hasTorpedo() == false);
	}

	
	
	
	
}







