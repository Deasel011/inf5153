package battleship.opponent;


import battleship.domain.*;
import battleship.domain.match.MatchSide;
import battleship.domain.opponent.*;
import battleship.domain.util.*;

public class IntelligentOpponent extends OpponentAlgorithm {
	
	public boolean encodingEqualsCustom(IntelligentOpponent other) {
		return (
			opGrid.encodingEquals(other.opGrid) && 
			getName().equals(other.getName())
		);
	}
	
	public String getName() {
		return "intelligent";
	}
	
	public IntelligentOpponent(OpponentGrid opGrid) {
		super(opGrid);
	}
	
	public CellList<OpponentCell> getNextCells() {
		CellList<OpponentCell> cells = getCellsThatMaximizeHeuristic();
		if(!cells.isEmpty()) {
			return cells;
		} else {
			return (new RandomOpponent(getOpGrid())).getNextCells();
		}
	}

	
	CellList<OpponentCell> getCellsThatMaximizeHeuristic() {
		CellList<OpponentCell> cellsWithUnknownShip = getOpGrid().getCellsPP().filter(cell -> cell.hasUnknownShip());
		CellList<OpponentCell> neighbors = getAllNeighborsWhereWeCouldShoot(cellsWithUnknownShip);		
		CellList<OpponentCell> cells = new CellList<>();
		int maximumHeuristicValue = getMaximumHeuristicValue(cellsWithUnknownShip, neighbors);
		
		int heuristicValue;
		for(OpponentCell nei: neighbors) {
			heuristicValue = getHeuristicValueForNeighbor(cellsWithUnknownShip, nei);
			if(heuristicValue == maximumHeuristicValue) {
				cells.add(nei);
			}
		}
		return cells;
		
	}
	
	int getMaximumHeuristicValue(CellList<OpponentCell> cellsWithUnknownShip, CellList<OpponentCell> neighbors) {
		int maximumHeuristicValue = 0;
		int heuristicValue;
		for(OpponentCell nei: neighbors) {
			heuristicValue = getHeuristicValueForNeighbor(cellsWithUnknownShip, nei);
			maximumHeuristicValue = Math.max(heuristicValue, maximumHeuristicValue);
		}
		return maximumHeuristicValue;
	}
	
	
	CellList<OpponentCell> getAllNeighborsWhereWeCouldShoot(CellList<OpponentCell> cellsWithUnknownShip) {
		CellList<OpponentCell> neighbors = new CellList<>();
		for(OpponentCell cell: cellsWithUnknownShip) {
			for(Cell nei: cell.getManhattanNeighbors()) {
				if(!nei.hasTorpedo() && !neighbors.contains(nei)) {
					neighbors.add((OpponentCell)nei);
				}
			}
		}
		return neighbors;
	}
	
	int getHeuristicValueForNeighbor(CellList<OpponentCell> cellsWithUnknownShip, OpponentCell neighbor) {
		assertThat(!cellsWithUnknownShip.contains(neighbor));
		CellList<OpponentCell> importantCells = (CellList<OpponentCell>) cellsWithUnknownShip.clone();
		importantCells.add(neighbor);
		TpList<Cell> importantCellsForThisAlignment;
		int heuristicValue = 0;
		
		for(int row: getOpGrid().getRowIndexes()) {
			importantCellsForThisAlignment = getOpGrid().getRowCells(row).filter(cell -> importantCells.contains(cell));
			heuristicValue += getHeuristicAlignedPositions(importantCellsForThisAlignment.map(c -> c.getCol()));
		}
		for(int col: getOpGrid().getColIndexes()) {
			importantCellsForThisAlignment = getOpGrid().getColCells(col).filter(cell -> importantCells.contains(cell));
			heuristicValue += getHeuristicAlignedPositions(importantCellsForThisAlignment.map(c -> c.getRow()));
		}
		
		return heuristicValue;
	}
	
	int getHeuristicAlignedPositions(TpList<Integer> position) {
		return getHeuristicForLengths(Util.getConsecutiveRange(position).map(r -> r.size()));
	}
	
	
	int getHeuristicForLengths(TpList<Integer> lengths) {
		for(int length: lengths) {
			assertThat(length > 0);
		}
		return (int) lengths.map(length -> Math.pow(10, length - 1)).sum();
	}
	
	
	
}





