
package battleship.domain;


import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public class Torpedo extends GridElement {
	
	protected Cell cell;
	protected TorpedoFeedback feedback;
	
	public Torpedo(Grid grid, Cell cell) {
		super(grid);
		this.cell = cell;
		this.cells.add(cell);
		this.feedback = feedback;
		assertThat(grid.cells.contains(cell));
	}
	
	public void setFeedback(TorpedoFeedback feedback) {
		this.feedback = feedback;
	}
	
	public TorpedoFeedback getFeedback() {
		assertThat(feedback != null);
		return feedback;
	}
	
	public boolean encodingEqualsCustom(Torpedo other) {
		return (
			getCell().getName().equals(other.getCell().getName())
		);
	}
	
	public Cell getCell() {
		return getCells().one();
	}


}





