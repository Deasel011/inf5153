package battleship.domain.personal;

import java.util.ArrayList;
import java.util.List;


import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;


public class PersonalCell extends Cell {
	
	PersonalGrid ownGrid;
	
	public PersonalCell(PersonalGrid grid, int row, int col) {
		super(grid, row, col);
		ownGrid = grid;
	}
	
	public boolean hasShip() {
		return !getShips().isEmpty();
	}
	
	public PersonalShip getShip() {
		return getShips().one();
	}
	
	
	public char getShowReprShipSymbol() {
		assertThat(hasShip());
		return getShip().getShipSymbol();
	}
	
	
	private TpList<PersonalShip> getShips() {
		TpList<PersonalShip> ships = new TpList<>();
		
		for(Ship ship: ownGrid.getShips() ) {
			if(ship.getCells().contains(this)) {
				ships.add((PersonalShip)(Object)ship);
			}
		}
		return ships;
	}
}





