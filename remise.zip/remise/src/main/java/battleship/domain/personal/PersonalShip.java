package battleship.domain.personal;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;

public class PersonalShip extends Ship {
	
	
	//Orientation orientation = null;
	
	PersonalShip(Grid grid, ShipInfo info) {
		super(grid, info);
	}
	
	public boolean isPlaced() {
		return cell != null;
	}
	
	public boolean isSinked() {
		assertThat(isPlaced());
		assertThat(getCells().size() > 0);
		for(Cell cell: getCells()) {
			if(!cell.hasTorpedo()) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public String toString() {
		return _repr(info.toString() + ", isPlaced()=" + isPlaced());
	}
	
	public void setPosition(Cell cell, Orientation orientation) throws InvalidShipPosition {
		assertThat(grid.getCells().contains(cell));
		
		CellList<Cell> totalCells;
		try {
			totalCells = cell.getAlignedCellsFromHereTo(orientation, info.getNumCase());
		} catch (InvalidCellPosition e) {
			throw new InvalidShipPosition();
		}
		
		for(Cell nextCell: totalCells) {
			if(nextCell.hasShip()) {
				getCells().clear();
				throw new InvalidShipPosition();
			}
			getCells().add(nextCell);
		}
		
		this.cell = cell;
		this.orientation = orientation;
	}
	
	public void placeAtCell(PersonalCell cell, Orientation orientation) throws InvalidShipPosition {
		assertThat(!isPlaced());
		setPosition(cell, orientation);
	}
	
	public void placeAtCellName(String cellName, Orientation orientation) throws InvalidShipPosition {
		placeAtCell((PersonalCell)grid.cellFromName(cellName), orientation); 
	}
	
	public boolean encodingEqualsCustom(PersonalShip other) {
		return (
			isPlaced() == other.isPlaced() &&
			cell.getName().equals(other.cell.getName()) &&
			orientation.equals(other.orientation)
		);
	}


	
	
	

}





