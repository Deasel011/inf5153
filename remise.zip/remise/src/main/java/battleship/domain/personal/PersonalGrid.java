package battleship.domain.personal;


import battleship.domain.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;

public class PersonalGrid extends Grid {
	
	public PersonalGrid(Config config) {
		super(config);
	}
	
	protected PersonalShip createNewShip(ShipInfo info) {
		return new PersonalShip(this, info);
	}
	
	public boolean hasLost() {
		return getShipsPP().filter(ship -> ship.isSinked() == false).isEmpty();
	}
	
	public void placeAllShipsRandomly() {
		PersonalShip unplacedShip;
		TpList<PersonalShip> unplacedShips;
		
		Cell availableCell;
		Orientation orientation;
		 
		int count = 0;
		
		while(true) {
			
			count += 1;
			
			if(count == 1000) {
				// si on a pas réussi après X fois, on recommence du début.
				for(PersonalShip ship: getShipsPP()) {
					ship.resetPosition();
				}
				count = 0;
			}
			
			unplacedShips = getShipsPP().filter(ship -> ship.isPlaced() == false);
			
			if(unplacedShips.isEmpty()) {
				return;
			}
			
			unplacedShip = unplacedShips.randomChoice();
			
			availableCell = getCells().filter(cell -> cell.hasShip() == false).randomChoice();
			orientation = Orientation.getAllOrientations().randomChoice();
			
			try {
				unplacedShip.placeAtCell((PersonalCell)availableCell, orientation);
			} catch (InvalidShipPosition e) {
				
			}
			
			
		}
	}
	
	public boolean encodingEqualsCustom(PersonalGrid other) {
		return (
				config.encodingEquals(other.config) &&
				torpedos.encodingEquals(other.torpedos) &&
				ships.encodingEquals(other.ships)
		);
	}
	
	public PersonalShip shipFromSymbol(char symbol) {
		return (PersonalShip)super.shipFromSymbol(symbol);
	}
	
	public Cell createNewCell(int row, int col) {
		return new PersonalCell(this, row, col);
	}
	
	public TpList<PersonalShip> getShipsPP() {
		return (TpList<PersonalShip>)(Object)super.getShips();
	}

	public PersonalTorpedo newTorpedoAtCellName(String cellName) {
		return newTorpedoAtCell(cellFromName(cellName));
	}
	
	public PersonalTorpedo newTorpedoAtCell(Cell cell) {
		PersonalTorpedo torpedo = new PersonalTorpedo(this, cell);
		torpedos.add(torpedo);
		torpedo.setFeedback(torpedo.createNewTorpedoFeedback());
		return torpedo;
	}

	public boolean areAllShipsPlaced() {
		return getShipsPP().filter(ship -> ship.isPlaced() == false).isEmpty();
	}


}





