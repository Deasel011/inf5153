package battleship.domain.personal;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;


public class PersonalTorpedo extends Torpedo {


	public PersonalTorpedo(PersonalGrid grid, Cell cell) {
		super(grid, cell);
	}
	
	public TorpedoFeedback createNewTorpedoFeedback() {
		if(isInWater()) {
			return new TorpedoFeedback("water", cell.getName(), null, null, null);
		} else {
			PersonalShip ship = getShip();
			if(ship.isSinked()) {
				return new TorpedoFeedback("sinked", cell.getName(), ship.getShipIdent(), ship.getCell().getName(), ship.getOrientation().getName());
			} else {
				return new TorpedoFeedback("touched", cell.getName(), null, null, null);
			}
		}
	}
	
	public boolean isInWater() {
		return !cell.hasShip();
	}
	
	public boolean isInShip() {
		return cell.hasShip();
	}
	
	public PersonalShip getShip() {
		return ((PersonalCell)cell).getShip();
	}
	
	public boolean encodingEqualsCustom(PersonalTorpedo other) {
		return (
			cell.getName().equals(other.cell.getName())
		);
	}

}





