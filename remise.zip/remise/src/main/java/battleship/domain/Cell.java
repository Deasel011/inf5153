package battleship.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;


public abstract class Cell extends TpObject {
	
	protected Grid grid;
	protected int row;
	protected int col;
	protected int id;
	
	
	public Cell(Grid grid, int row, int col) {
		this.grid = grid;
		this.row = row;
		this.col = col;
		this.id = row * grid.width + col;
	}
	
	public String getName() {
		return "" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(row) + (col + 1);
	}
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public CellList<Cell> getManhattanNeighbors() {
		CellList<Cell> cells = new CellList<>();
		if(hasLeftNeighbor())
			cells.add(getLeftNeighbor());
		if(hasRightNeighbor())
			cells.add(getRightNeighbor());
		if(hasUpNeighbor())
			cells.add(getUpNeighbor());
		if(hasDownNeighbor())
			cells.add(getDownNeighbor());
		return cells;
	}
	
	public CellList<Cell> getAlignedCellsFromHereTo(Orientation orientation, int numCase) throws InvalidCellPosition {
		 assertThat(numCase>=1);
		 CellList<Cell> cells = new  CellList<>();
		 
		 cells.add(this);
		 Cell cell = this;
		 for(int i: Util.range(numCase - 1)) {
			 cell = cell.getOffsetCell(orientation.getRowOffset(), orientation.getColOffset());
			 if(cell == null) {
				 throw new InvalidCellPosition();
			 }
			 cells.add(cell);
		 }
		 return cells;
		
	}
	
	private TpList<Torpedo> getTorpedos() {
		return grid.torpedos.filter(torpedo -> torpedo.getCell() == this);
	}
	
	public boolean hasTorpedo() {
		return !getTorpedos().isEmpty();
	}
	
	public Torpedo getTorpedo() {
		return getTorpedos().one();
	}

	
	public Cell getLeftNeighbor() {
		return getOffsetCell(0, -1);
	}
	
	public Cell getRightNeighbor() {
		return getOffsetCell(0, 1);
	}
	
	public Cell getUpNeighbor() {
		return getOffsetCell(-1, 0);
	}
	
	public Cell getDownNeighbor() {
		return getOffsetCell(1, 0);
	}
	
	public Cell getOffsetCell(int rowOffset, int colOffset) {
		int newRow = row + rowOffset;
		int newCol = col + colOffset;
		if(grid.getRowIndexes().contains(newRow) && grid.getColIndexes().contains(newCol)) {
			return grid.cells2d[newRow][newCol];
		}
		else {
			return null;
		}
	}
	
	public abstract boolean hasShip();
	
	
	public boolean hasLeftNeighbor() {
		return getLeftNeighbor() != null;
	}
	
	public boolean hasRightNeighbor() {
		return getRightNeighbor() != null;
	}
	
	public boolean hasUpNeighbor() {
		return getUpNeighbor() != null;
	}
	
	public boolean hasDownNeighbor() {
		return getDownNeighbor() != null;
	}
	
	public String getShowRepr() {
		return getShowRepr(new CellList<Cell>());
	}

	public String getShowRepr(CellList<Cell> cellsToHighlight) {
		boolean has_ship = hasShip();
		boolean is_highlighted = cellsToHighlight.contains(this);
		boolean has_torpedo = hasTorpedo();
		
		String key = "" + Util.boolToInt(has_ship) + Util.boolToInt(has_torpedo) + Util.boolToInt(is_highlighted);
		
		HashMap<String, String> mapping = new HashMap<>();
		
		mapping.put("111", "◄{symbol}►");
		mapping.put("110", "<{symbol}>");
		mapping.put("101", "({symbol})");
		mapping.put("100", " {symbol} ");
		mapping.put("011", "(●)");
		mapping.put("010", " ● ");
		mapping.put("001", "(-)");
		mapping.put("000", " - ");
		
		String value = mapping.get(key);
		
		if(value.contains("{symbol}")) {
			value = value.replace("{symbol}", "" + getShowReprShipSymbol());
		}

		return value;
	}
	

	
	public abstract char getShowReprShipSymbol();

	
	public void show() {
		grid.show(grid.cells.filter(p -> p == this));
	}
	
	@Override
	public String toString() {
		return _repr(getName() + ", " + getShowRepr());
	}
	
	
}





