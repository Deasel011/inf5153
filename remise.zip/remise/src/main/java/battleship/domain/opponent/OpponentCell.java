package battleship.domain.opponent;


import java.util.ArrayList;
import java.util.List;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.personal.*;




public class OpponentCell extends Cell {
	
	public OpponentCell(Grid grid, int row, int col) {
		super(grid, row, col);
	}
	
	public boolean encodingEqualsCustom(OpponentCell other) {
		return (
				getName().equals(other.getName())
		);
	}
	
	public char getShowReprShipSymbol() {
		assertThat(hasShip());
		if(hasUnknownShip()) {
			return '?';
		} else {
			return getKnownShip().getShipSymbol();
		}
	}
	
	public boolean hasUnknownShip() {
		return hasTorpedo() && getTorpedo().isShipUnknown();
	}
	
	public OpponentShip getKnownShip() {
		if(hasUnknownShip() || !hasShip()) {
			return null;
		} else {
			assertThat(getTorpedo().discoveredShip != null);
			return getTorpedo().discoveredShip;
			//int ident = getTorpedo().getFeedback().getShipIdent();
			//return (OpponentShip)grid.getShips().filter(ship -> ship.getShipIdent() == ident).one();
		}
	}
	
	
	public OpponentTorpedo getTorpedo() { 
		return (OpponentTorpedo)super.getTorpedo(); // vive la réutilisation de code.
	}
	
	public boolean hasShip() {
		if(hasTorpedo()) {
			return getTorpedo().getFeedback().isTouched();
		} else {
			return false;
		}
	}
	

	
}





