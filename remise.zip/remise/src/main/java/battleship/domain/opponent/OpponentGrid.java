package battleship.domain.opponent;


import java.util.ArrayList;
import java.util.List;
import battleship.domain.*;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.personal.*;


public class OpponentGrid extends Grid {
	
	public OpponentGrid(Config config) {
		super(config);
	}
	
	protected OpponentShip createNewShip(ShipInfo info) {
		return new OpponentShip(this, info);
	}
	
	public boolean encodingEqualsCustom(OpponentGrid other) {
		return (
				config.encodingEquals(other.config) &&
				torpedos.encodingEquals(other.torpedos) &&
				ships.encodingEquals(other.ships)
		);
	}
	
	public Cell createNewCell(int row, int col) {
		return new OpponentCell(this, row, col);
	}
	
	public CellList<OpponentCell> getCellsPP() {
		return (CellList<OpponentCell>)(CellList<?>)getCells();
	}
	
	public TpList<OpponentTorpedo> getTorpedosPP() {
		return (TpList<OpponentTorpedo>)(Object)super.getTorpedos();
	}
	
	public OpponentTorpedo newTorpedoFromData(String cellName, String feedbackSymbol) {
		return newTorpedoFromData(cellName, feedbackSymbol, null, null, null);
	}
	
	public OpponentTorpedo newTorpedoFromData(String cellName, String feedbackSymbol, Integer shipIdent, String shipCellName, String shipOrientationName) {
		TorpedoFeedback feedback = new TorpedoFeedback(feedbackSymbol, cellName, shipIdent, shipCellName, shipOrientationName);
		return newTorpedoFromFeedback(feedback);
	}
	
	public OpponentTorpedo newTorpedoFromFeedback(TorpedoFeedback feedback) {
		Cell cell = cellFromName(feedback.getCellName());
		OpponentTorpedo torpedo = new OpponentTorpedo(this, cell, feedback);
		getTorpedos().add(torpedo);
		if(feedback.isSinked()){
			OpponentShip ship = (OpponentShip)shipFromIdent(feedback.getShipIdent());
			
			try {
				ship.discoverAtCellName(feedback.getShipCellName(), Orientation.fromName(feedback.getShipOrientationName()));
			} catch (InvalidShipPosition e) {
				e.printStackTrace();
				assertThat(false);
			}
			
		}
		return torpedo;
	}
	
	public TpList<OpponentShip> getShipsPP() {
		return (TpList<OpponentShip>)(Object)super.getShips();
	}
	public boolean hasWinned() {
		return getShipsPP().filter(ship -> ship.wasDiscovered() == false).isEmpty();
	}

}





