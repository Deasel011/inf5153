package battleship.domain.opponent;



import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.personal.*;

public class OpponentShip extends Ship {
	
	public OpponentShip(OpponentGrid grid, ShipInfo info) {
		super(grid, info);
	}
	
	public boolean wasDiscovered() {
		return getCell() != null;
	}
	
	public void discoverAtCellName(String cellName, Orientation orientation) throws InvalidShipPosition {
		discoverAtCell(grid.cellFromName(cellName), orientation);
	}
	
	public void discoverAtCell(Cell cell, Orientation orientation) throws InvalidShipPosition {
		assertThat(grid.getCells().contains(cell));
		CellList<Cell> shipCells;
		try {
			shipCells = cell.getAlignedCellsFromHereTo(orientation, info.getNumCase());
		} catch (InvalidCellPosition e) {
			
			throw new InvalidShipPosition();
			
		}
		
		OpponentTorpedo torpedo;
		

		
		setPosition(cell, orientation);
		
		for(Cell shipCell: shipCells) {
			torpedo = (OpponentTorpedo)shipCell.getTorpedo();
			if(torpedo == null) {
				throw new InvalidShipPosition();
			};
			torpedo.setDiscoveredShip(this);
		}
	}
	
	public void setPosition(Cell cell, Orientation orientation) throws InvalidShipPosition {
		assertThat(grid.getCells().contains(cell));
		
		CellList<Cell> totalCells;
		try {
			totalCells = cell.getAlignedCellsFromHereTo(orientation, info.getNumCase());
		} catch (InvalidCellPosition e) {
			throw new InvalidShipPosition();
		}
		
		for(Cell nextCell: totalCells) {
			OpponentCell nextCellPP = (OpponentCell)nextCell;
			if(!nextCellPP.hasUnknownShip()) {
				getCells().clear();
				throw new InvalidShipPosition();
			}
			getCells().add(nextCell);
		}
		
		this.cell = cell;
		this.orientation = orientation;
	}
	public boolean encodingEqualsCustom(OpponentShip other) {
		return (
				wasDiscovered() == other.wasDiscovered() &&
				getCells().encodingEquals(other.getCells())
		);
	}

	

}





