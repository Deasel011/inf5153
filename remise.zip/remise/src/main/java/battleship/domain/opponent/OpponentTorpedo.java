package battleship.domain.opponent;



import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.personal.*;

public class OpponentTorpedo extends Torpedo {

	OpponentShip discoveredShip;
	
	public OpponentTorpedo(OpponentGrid grid, Cell cell, TorpedoFeedback feedback) {
		super(grid, cell);
		setFeedback(feedback);
		assertThat(cell.hasTorpedo() == false);
	}
	
	@Override
	public String toString() {
		return _repr(feedback.getCellName() + ", " + feedback.getFeedbackTypeName());
	}
	
	public boolean encodingEqualsCustom(OpponentTorpedo other) {
		return (
				feedback.encodingEquals(other.feedback)
		);
	}
	
	public void setDiscoveredShip(OpponentShip ship) {
		assertThat(feedback.isTouched());
		assertThat(hasDiscoveredShip() == false);
		assertThat(discoveredShip == null);
		discoveredShip = ship;
		assertThat(hasDiscoveredShip());
	}
	
	
	public boolean hasDiscoveredShip() {
		return discoveredShip != null;
	}

	public boolean isShipUnknown() {
		return feedback.isTouched() && hasDiscoveredShip() == false;
	}


}





