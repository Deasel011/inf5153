package battleship.domain;


import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public abstract class OpponentAlgorithm extends TpObject implements Cloneable {
	
	protected OpponentGrid opGrid;

	public OpponentAlgorithm(OpponentGrid opGrid) {
		this.opGrid = opGrid;
	}

	public OpponentGrid getOpGrid() {
		return opGrid;
	}
	
	protected Object clone() throws CloneNotSupportedException {
	    return (OpponentAlgorithm)super.clone();
	 }
	  
	public OpponentAlgorithm cloneWithNewOpGrid(OpponentGrid opGrid) {
		OpponentAlgorithm algo = null;
		try {
			algo = (OpponentAlgorithm) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			assertThat(false);
		}
		algo.opGrid = opGrid;
		return algo;
	}
	
	public abstract String getName();
	
	public abstract CellList<OpponentCell> getNextCells();
	
	public OpponentCell getNextCell() {
		OpponentCell cell = getNextCells().randomChoice();
		assertThat(!cell.hasTorpedo());
		return cell;
	}
	
	public boolean encodingEqualsCustom(OpponentAlgorithm other) {
		return (
			true
		);
	}
	
	
}





