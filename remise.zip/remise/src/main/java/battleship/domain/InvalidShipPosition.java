package battleship.domain;


public class InvalidShipPosition extends Exception {

}





