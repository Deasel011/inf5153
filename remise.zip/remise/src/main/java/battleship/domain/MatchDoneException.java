package battleship.domain;


public class MatchDoneException extends Exception {

}





