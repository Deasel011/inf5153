package battleship.domain;


public class InvalidCellPosition extends Exception {

}





