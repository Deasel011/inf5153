package battleship.domain;

import java.util.ArrayList;
import java.util.List;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public class Board extends TpObject{
	
	Config config;
	OpponentGrid opGrid;
	PersonalGrid ownGrid;
	
	public Board(Config config) {
		this.config = config;
		this.opGrid = new OpponentGrid(config);
		this.ownGrid = new PersonalGrid(config);
	}
	
	public void setOpGrid(OpponentGrid opGrid) {
		assertThat(opGrid.config == config);
		this.opGrid = opGrid;
	}
	
	public void setOwnGrid(PersonalGrid ownGrid) {
		assertThat(ownGrid.config == config);
		this.ownGrid = ownGrid;
	}
	
	public boolean encodingEqualsCustom(Board other) {
		return (
			config.encodingEquals(other.config) &&
			opGrid.encodingEquals(other.opGrid) &&
			ownGrid.encodingEquals(other.ownGrid)
		);
	}
	
	
	@Override
	public String toString() {
		return "<Board>";
	}

	public PersonalGrid getOwnGrid() {
		return ownGrid;
	}
	
	public OpponentGrid getOpGrid() {
		return opGrid;
	}
	
	public Config getConfig() {
		return config;
	}
	
}





