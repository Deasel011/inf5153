package battleship.domain;


public class UnplacedShipException extends Exception {

}





