package battleship.domain;

import java.util.ArrayList;
import java.util.List;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public abstract class Grid extends TpObject {
	
	protected Cell[][] cells2d;
	protected CellList<Cell> cells;
	protected int width;
	protected int height;
	protected Config config;
	protected TpList<Torpedo> torpedos;
	protected TpList<Ship> ships;
	
	public Grid(Config config) {
		this.config = config;
		this.width = config.width;
		this.height = config.height;
		this.cells = new CellList<>();
		this.cells2d = new Cell[height][width];
		this.torpedos = new TpList<>();
		this.ships = new TpList<>();
		
		initializeCells();
		initializeShips();
	}
	
	public Ship shipFromIdent(int ident) {
		return ships.filter(ship -> ship.getShipIdent() == ident).one();
	}
	
	public abstract Cell createNewCell(int row, int col);
	
	private void initializeCells() {
		for(int row: getRowIndexes()) {
			for(int col: getColIndexes()) {
				Cell cell = createNewCell(row, col);
				cells.add(cell);
				cells2d[row][col] = cell;
			}
		}
	}
	
	protected abstract Ship createNewShip(ShipInfo info);
	
	private void initializeShips() {
		for(ShipInfo info: config.getShips()) {
			ships.add(createNewShip(info));
		}
	}
	
	public Cell cellFromName(String name) {
		return cells.filter(cell -> cell.getName().equals(name)).one();
	}
	
	public CellList<Cell> getCells() {
		return cells;
	}
	
	public TpList<Torpedo>getTorpedos() {
		return torpedos;
	}
	
	public TpList<Ship> getShips() {
		return ships;
	}
	
	public TpList<Cell> getRowCells(int row) {
		return cells.filter(cell -> cell.row == row);
	}
	
	public TpList<Cell> getColCells(int col) {
		return cells.filter(cell -> cell.col == col);
	}
	
	public List<Integer> getRowIndexes() {
		return Util.range(height);
	}
	
	public List<Integer> getColIndexes() {
		return Util.range(width);
	}
	
	public void show() {
		show(new CellList<>());
	}
	
	public void show(CellList<Cell> cellsToHighlight) {
		for(Cell hcell: cellsToHighlight) {
			assertThat(cells.contains(hcell));
		}
		
		String output;
		String rowName;
		String line;
		
		output = "   ";
		for(int col: getColIndexes()) {
			output += " " + (col + 1) + " ";
		}
		output += '\n';
		
		for(int row: getRowIndexes()) {
			
			// OUI! ca va planter si on a plus que 26 colonnes!
			rowName = "" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(row);
			line = rowName + "  ";
			
			for(int col: getColIndexes()) {
				line += cells2d[row][col].getShowRepr(cellsToHighlight);
			}
			output += line + '\n';
			
		}
		
		System.out.flush();
		System.err.flush();
		System.out.println(output);
		System.out.flush();
		
	}
	
	public Ship shipFromSymbol(char symbol) {
		return ships.filter(ship -> ship.getShipSymbol() == (symbol)).one();
	}
	

	
}





