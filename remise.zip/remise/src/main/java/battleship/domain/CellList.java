package battleship.domain;

import java.util.ArrayList;
import java.util.function.Predicate;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public class CellList<T> extends TpList<T> {
	
	public CellList<T> filter(Predicate<T> predicate) {
		// est-ce qu'il y a moyen de ne pas être oubligé de redéfinir à chaque niveau?
		return (CellList<T>) super.filter(predicate);
	}
	
	public void show() {
		if(isEmpty()) {
			System.out.println("<liste de cellule vide>");
		} else {
			((Cell)get(0)).grid.show((CellList<Cell>)this);
		}
	}
}



