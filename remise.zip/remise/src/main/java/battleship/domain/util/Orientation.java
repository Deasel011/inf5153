package battleship.domain.util;

import java.util.ArrayList;
import java.util.List;



public class Orientation extends TpObject {
	
	String name;
	private static Orientation down;
	private static Orientation right;
	
	private Orientation(String name) {
		this.name = name;
		assertThat(name.equals("down") || name.equals("right"));
	}
	
	public static Orientation fromName(String name) {
		if(name.equals("right")) {
			return right();
		} else if (name.equals("down")) {
			return down();
		} else {
			assertThat(false);
			return null;
		}
	}
	
	public static Orientation right() {
		if(right == null) {
			right = new Orientation("right");
		}
		return right;
	}
	
	public static TpList<Orientation> getAllOrientations() {
		TpList<Orientation> orientations = new TpList<>();
		orientations.add(right());
		orientations.add(down());
		return orientations;
	}
	
	public static Orientation down() {
		if(down == null) {
			down = new Orientation("down");
		}
		return down;
	}
	
	public int getRowOffset() {
		if(isDown()) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public int getColOffset() {
		if(isRight()) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public boolean isDown() {
		return name.equals("down");
	}
	
	public boolean isRight() {
		return name.equals("right");
	}

	public String getName() {
		return name;
	}
	
}





