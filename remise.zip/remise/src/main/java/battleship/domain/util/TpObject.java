package battleship.domain.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TpObject {
	
	protected String _repr(String inner) {
		return "<" + getClass().getSimpleName() + ": " + inner + ">";
	}
	
	public static void assertThat(boolean condition) {
		if(!condition) {
			throw new RuntimeException();
		}
	}
	
	public boolean encodingEqualsCustom(Object other) {
		assertThat(false);
		return false;
	}
	
	public final boolean encodingEquals(Object other) {
		if(!getClass().equals(other.getClass())) {
			return false;
		}
		
		Method method;
		try {
			method = other.getClass().getDeclaredMethod("encodingEqualsCustom", other.getClass());
			return (boolean)method.invoke (other, other);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
			assertThat(false);
		} catch (SecurityException e) {
			e.printStackTrace();
			assertThat(false);
		}catch (InvocationTargetException e) {
			e.printStackTrace();
			assertThat(false);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			assertThat(false);
		}
		
		assertThat(false);
		return false;
	}

}





