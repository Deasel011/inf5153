package battleship.domain.util;

import java.util.ArrayList;
import java.util.Random;
import java.util.function.Predicate;



public class TpList<T> extends ArrayList<T> {
	
	
	public boolean encodingEquals(TpList<T> other) {
		
		if(size() != other.size()) {
			return false;
		}
		for(int i = 0; i < size(); i++) {
			
			if(!((TpObject)get(i)).encodingEquals(other.get(i)) ){
				return false;
			}
		}
		return true;
	}
	
	static Random randomGenerator = new Random();
	
	public T randomChoice() {
		TpObject.assertThat(size() > 0);
        int index = randomGenerator.nextInt(size());
        return get(index);
	}
	
	
	public TpList<T> filter(Predicate<T> predicate) {
		TpList<T> newList = (TpList<T>) super.clone();
		newList.clear();
		for(T element: this) {
			if(predicate.test(element)) {
				newList.add(element);
			}
		}
		return newList;
	}
	
	public double sum() {
		int total = 0;
		for(Object element: this) {
			total += (double) element;
		}
		return total;
	}
	
	
	public <Out> TpList<Out> map(Func<T, Out> f) {
		TpList<Out> out = new TpList<Out>();
	    for (T inObj : this) {
	        out.add(f.apply(inObj));
	    }
	    return out;
	}
	
	
	public T one() {
		if(size() != 1) {
			throw new RuntimeException();
		}
		return get(0);
	}
	
	
	
	public interface Func<T, Out> {
	    public Out apply(T in);
	}
	
}





