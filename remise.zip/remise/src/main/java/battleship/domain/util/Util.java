package battleship.domain.util;

import java.util.ArrayList;
import java.util.List;

import battleship.domain.*;

public abstract class Util {
	
	public static List<Integer> range(int stop) {
		List<Integer> ints = new ArrayList<>();
		for(int i = 0; i < stop; i++) {
			ints.add(i);
		}
		return ints;
	}
	
	public static int boolToInt(boolean bool) {
		if(bool) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public static TpList<TpList<Integer>> getConsecutiveRange(TpList<Integer> ints) {
		/*
		    assert get_consecutive_ranges([]) == []
			assert get_consecutive_ranges([1]) == [[1]]
			assert get_consecutive_ranges([1, 2]) == [[1, 2]]
			assert get_consecutive_ranges([1, 3]) == [[1], [3]]
			assert get_consecutive_ranges([1, 3, 4]) == [[1], [3, 4]]
			assert get_consecutive_ranges([0, 1, 3, 4]) == [[0, 1], [3, 4]]
			assert get_consecutive_ranges([0, 1, 3, 4]) == [[0, 1], [3, 4]]
			assert get_consecutive_ranges([-1, -2, -3, 0, 1, 3, 4, 9]) == [[-1], [-2], [-3], [0, 1], [3, 4], [9]]
			assert get_consecutive_ranges([-3, -2, -1, 0, 1, 3, 4, 9]) == [[-3, -2, -1, 0, 1], [3, 4], [9]]
		 */
		TpList<TpList<Integer>> currentRanges = new TpList<>(); 
		
		if(ints.isEmpty()) {
			return currentRanges;
		}
		
		int previous = ints.get(0);
		TpList<Integer> currentRange = new TpList<>();
		currentRange.add(previous);
		currentRanges.add(currentRange);
		
		int num;
		for(int i: range(ints.size() - 1)) {
			num = ints.get(i);
			if(num == previous + 1) {
				currentRange.add(num);
			} else {
				currentRange = new TpList<>();
				currentRange.add(num);
				currentRanges.add(currentRange);
			}
			previous = num;
		}
		
		return currentRanges;
	}

	public static boolean nullSafeEquals(Object a, Object b) {
		if(a == null && b == null) {
			return true;
		}
		if(a == null || b == null) {
			return false;
		}
		return a.equals(b);
		
	}
	
}





