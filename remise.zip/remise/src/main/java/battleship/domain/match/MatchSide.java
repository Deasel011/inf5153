
package battleship.domain.match;


import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;

public class MatchSide extends TpObject {

	protected Match match;
	protected Board board;
	protected OpponentAlgorithm algo;
	
	public MatchSide(Match match) {
		this.match = match;
		setBoard(new Board(match.config));
	}
	
	public PersonalGrid getOwnGrid() {
		return board.getOwnGrid();
	}
	
	public OpponentGrid getOpGrid() {
		return board.getOpGrid();
	}
	
	public MatchSide getOtherSide() {
		return match.sides.filter(side -> side != this).one();
	}
	
	public boolean isMatchDone() {
		return getWinner() != null;
	}
	
	public MatchSide getWinner() {
		
		if (getOwnGrid().hasLost()) {
			return getOtherSide();
		}
		
		if (getOpGrid().hasWinned()) {
			return this;
		}
		
		return null;
		
	}
	
	public TorpedoFeedback playAgainstOpponent(String cellName) throws MatchDoneException, UnplacedShipException {
		// playPlyAtCellName, playAgainstOpponent
		match.assertSyncedSides();
		if(getOwnGrid().areAllShipsPlaced() == false) {
			throw new UnplacedShipException();
		}
		if(isMatchDone()) {
			throw new MatchDoneException();
		}
		PersonalTorpedo otherSideTorpedo = getOtherSide().getOwnGrid().newTorpedoAtCellName(cellName);
		
    	OpponentCell cell = (OpponentCell)getOpGrid().cellFromName("B4");
    	System.out.println(cell.hasUnknownShip());
    	
		OpponentTorpedo opTorpedo = getOpGrid().newTorpedoFromFeedback(otherSideTorpedo.getFeedback());
		assertThat(otherSideTorpedo.getFeedback().encodingEquals(opTorpedo.getFeedback()));
		match.assertSyncedSides();
		return otherSideTorpedo.getFeedback();
	}
	
	public TorpedoFeedback playAgainstOpponentWithAlgo() throws MatchDoneException, UnplacedShipException {
		OpponentAlgorithm algo = match.algo.cloneWithNewOpGrid(getOpGrid());
		return playAgainstOpponent(algo.getNextCell().getName());
	}
	
	public boolean encodingEqualsCustom(MatchSide other) {
		if(algo == null) {
			return (
					match.config.encodingEquals(other.match.config) && 
					board.encodingEquals(other.board)
				);
		} else {
			return (
					match.config.encodingEquals(other.match.config) && 
					board.encodingEquals(other.board) &&
					algo.encodingEquals(other.algo)
				);
		}

	}
	
	public void setBoard(Board board) {
		assertThat(board.getConfig() == match.getConfig());
		this.board = board;
	}
	
	public OpponentAlgorithm getAlgo() {
		return algo;
	}

	public Board getBoard() {
		return board;
	}


	

	

}





