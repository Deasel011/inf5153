
package battleship.domain.match;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.encoding.Encoding;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;



public class Match extends TpObject {
	
	MatchSide side1;
	MatchSide side2;
	TpList<MatchSide> sides;
	Config config;
	OpponentAlgorithm algo;
	
	
	public Match(Config config) {
		this.config = config;
		setSide1(new MatchSide(this));
		setSide2(new MatchSide(this));
		this.algo = null;
	}
	
	public Config getConfig() {
		return config;
	}
	
	public boolean encodingEqualsCustom(Match other) {
		if(algo == null) {
			return sides.encodingEquals(other.sides);
		} else {
			return (
					sides.encodingEquals(other.sides) &&
					algo.encodingEquals(other.algo)
				);
		}

	}
	
	
	public void setSide1(MatchSide side) {
		assertThat(side.match == this);
		side1 = side;
		updateSides();
	}
	
	public void setSide2(MatchSide side) {
		assertThat(side.match == this);
		side2 = side;
		updateSides();
	}
	
	private void updateSides() {
		sides = new TpList<MatchSide>();
		sides.add(side1);
		sides.add(side2);
	}
	
	
	public OpponentAlgorithm getAlgo() {
		return algo;
	}
	
	public void setAlgo(OpponentAlgorithm algo) {
		this.algo = algo;
	}

	public MatchSide getSide1() {
		return side1;
	}
	
	public MatchSide getSide2() {
		return side2;
	}

	public OpponentGrid getAlgoGrid() {
		return getSide1().getBoard().getOpGrid();
	}

	public static Match createWithDefaultConfig() {
		return new Match(Config.createDefaultConfig());
	}
	
	
	
	public boolean isMatchDone() {
		assertThat(side1.isMatchDone() == side2.isMatchDone());
		return side1.isMatchDone();
	}
	
	
	public MatchSide getWinner() {
		assertThat(side1.getWinner() == side2.getWinner());
		return side1.getWinner();
	}
	
	
	
	public void assertSyncedSides() {
		assertSyncedSidesContentOnly();
		
		
    	Encoding encoding = new Encoding(); // TODO xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxXXXXXXXXXXXXXXXXXXXXXXXXXXXXX: NE PAS OUBLIER DE L'ENLEVER AVANT LA REMISE.
    	String encoded = encoding.encode(this);
    	Match newMatch = encoding.decode(encoded);
    	newMatch.assertSyncedSidesContentOnly();
    	assertThat(newMatch.encodingEquals(this));
		
		
		
		

	}
	
	public void assertSyncedSidesContentOnly() {
		assertThat(side1.getOwnGrid().getTorpedos().size() == side2.getOpGrid().getTorpedos().size());
		assertThat(side2.getOwnGrid().getTorpedos().size() == side1.getOpGrid().getTorpedos().size());
		
		int side1plies = side1.getOpGrid().getTorpedos().size();
		int side2plies = side1.getOwnGrid().getTorpedos().size();
		assertThat(side1plies == side2plies + 1 || side1plies == side2plies);
		
		Torpedo t1;
		Torpedo t2;
		
		for(int i: Util.range(side1.getOwnGrid().getTorpedos().size())) {
			t1 = side1.getOwnGrid().getTorpedos().get(i);
			t2 = side2.getOpGrid().getTorpedos().get(i);
			assertThat(t1.getFeedback().encodingEquals(t2.getFeedback()));
		}
		
		
		for(int i: Util.range(side2.getOwnGrid().getTorpedos().size())) {
			t1 = side2.getOwnGrid().getTorpedos().get(i);
			t2 = side1.getOpGrid().getTorpedos().get(i);
			assertThat(t1.getFeedback().encodingEquals(t2.getFeedback()));
		}

	}


	

}





