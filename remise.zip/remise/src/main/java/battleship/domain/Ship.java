
package battleship.domain;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public abstract class Ship extends GridElement {

	protected ShipInfo info;
	protected Cell cell = null;
	protected Orientation orientation;
	
	public Ship(Grid grid, ShipInfo info) {
		super(grid);
		this.info = info;
	}
	
	public char getShipSymbol() {
		return info.getSymbol();
	}
	
	public int getShipIdent() {
		return info.getIdent();
	}
	
	public Cell getCell() {
		return cell;
	}
	
	public Orientation getOrientation() {
		return orientation;
	}
	
	public abstract void setPosition(Cell cell, Orientation orientation) throws InvalidShipPosition; // todo: enlever le code en double (le copié collé que j,ai fait)
	

	
	public void resetPosition() {
		this.cell = null;
		this.orientation = null;
		this.cells.clear();
	}
	

}





