package battleship.domain;


import java.util.ArrayList;
import java.util.List;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.personal.*;


public class TorpedoFeedback extends TpObject {
	
	String cellName;
	String symbol; // utiliser une instance au lieu d'un string serait mieux. mais je suis tanné de programmer en Java.
	Integer shipIdent;
	String shipCellName;
	String shipOrientationName;
	
	public TorpedoFeedback(String symbol, String cellName, Integer shipIdent, String shipCellName, String shipOrientationName) {
		this.cellName = cellName;
		this.symbol = symbol;
		this.shipIdent = shipIdent;
		this.shipCellName = shipCellName;
		this.shipOrientationName = shipOrientationName;
				
		
		if(isSinked()) {
			assertThat(isTouched() && shipIdent != null && shipCellName != null && shipOrientationName != null);
		}
		assertThat(isTouched() || isSinked() || isWater());
	}
	
	public String getShipCellName() {
		return shipCellName;
	}
	
	public String getShipOrientationName() {
		return shipOrientationName;
	}
	
	public boolean encodingEqualsCustom(TorpedoFeedback other) {
		return (
			cellName.equals(other.cellName) &&
			symbol.equals(other.symbol) &&
			Util.nullSafeEquals(shipIdent, other.shipIdent) &&
			Util.nullSafeEquals(shipCellName, other.shipCellName) &&
			Util.nullSafeEquals(shipOrientationName, other.shipOrientationName)
		);
	}

	
	public String getFeedbackTypeName() {
		return symbol;
	}
	
	public String getCellName() {
		return cellName;
	}
	
	
	@Override
	public String toString() {
		return _repr(symbol + ", shipIdent=" + shipIdent);
	}
	
	public int getShipIdent() {
		assertThat(isTouched() && shipIdent != null);
		return shipIdent;
	}
	
	public boolean isTouched() {
		return symbol.equals("touched") || symbol.equals("sinked");
	}

	public boolean isSinked() {
		return symbol.equals("sinked");
	}
	
	public boolean isWater() {
		return symbol.equals("water");
	}
	
	public TorpedoFeedback createTouched(String cellName, Integer shipIdent, String shipCellName, String shipOrientationName) {
		return new TorpedoFeedback("touched", cellName, shipIdent, shipCellName, shipOrientationName);
	}
	
	public TorpedoFeedback createSinked(String cellName, Integer shipIdent, String shipCellName, String shipOrientationName) {
		return new TorpedoFeedback("sinked", cellName, shipIdent, shipCellName, shipOrientationName);
	}
	
	public TorpedoFeedback createWater(String cellName, Integer shipIdent, String shipCellName, String shipOrientationName) {
		return new TorpedoFeedback("water", cellName, shipIdent, shipCellName, shipOrientationName);
	}
}





