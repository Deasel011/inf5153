package battleship.domain;

import java.util.ArrayList;
import java.util.List;

import battleship.opponent.*;
import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public class Experim {

    public static void main(String[] args) {
    	Config config = Config.createDefaultConfig();
    	System.out.println(config);
    	
    	
    	Board board = config.newBoard();
    	//System.out.println(board);
    	

    	//board.ownGrid.getCells().get(0).show();
    	

    	board.opGrid.newTorpedoFromData("D5", "water");
    	board.opGrid.newTorpedoFromData("F4", "water");
    	board.opGrid.newTorpedoFromData("F6", "water");
    	
    	board.opGrid.newTorpedoFromData("E4", "touched");
    	board.opGrid.newTorpedoFromData("E5", "touched");
    	board.opGrid.newTorpedoFromData("F5", "touched");
    	
    	//System.out.println(board.opGrid.getTorpedos());
    	
    	OpponentAlgorithm r = new IntelligentOpponent(board.opGrid);
    	//r.getNextCells().show();
    	
    	
    	
    	
    	
    	//System.out.println(board.opGrid.cellFromName("F4"));

    	
    	
    	
    	ShipInfo info = new ShipInfo(5, "hello", 9, 'H');
    	//System.out.println(info.encodingEquals(info));
    	
    	
    	Match match = config.newMatch();
    	System.out.println(match.encodingEquals(match));

    }

}





