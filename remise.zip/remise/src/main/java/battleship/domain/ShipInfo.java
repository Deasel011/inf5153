
package battleship.domain;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public class ShipInfo extends TpObject {
	
	String name;
	int numCase;
	int ident;
	char symbol;
	
	public ShipInfo(int ident, String name, int numCase, char symbol) {
		this.ident = ident;
		this.name = name;
		this.numCase = numCase;
		this.symbol = symbol;
	}
	
	
	
	public boolean encodingEqualsCustom(ShipInfo other) {
		return (
			ident == other.ident &&
			name.equals(other.name) &&
			numCase == other.numCase
		);
	}
	
	
	public String getName() {
		return name;
	}
	
	public int getIdent() {
		return ident;
	}
	
	public int getNumCase() {
		return numCase;
	}
	
	@Override
	public String toString() {
		return "<ShipInfo: " + name + "/" + numCase + ">";
	}



	public char getSymbol() {
		return symbol;
	}

}





