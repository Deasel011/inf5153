package battleship.domain;

import java.util.ArrayList;
import java.util.List;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;


public class Config extends TpObject {
	
	int width;
	int height;
	TpList<ShipInfo> ships;

	public Config(int width, int height, TpList<ShipInfo> ships) {
		this.width = width;
		this.height = height;
		this.ships = ships;
	}
	
	
	public boolean encodingEqualsCustom(Config other) {
		return (
				width == other.width &&
				height == other.height &&
				ships.encodingEquals(other.ships)
		);
	}

	
	@Override
	public String toString() {
		return _repr("width=" + width + ", height=" + height + ", len(ships)=" + ships.size());
	}
	
	public static Config createDefaultConfig() {
		TpList<ShipInfo> ships = new TpList<>();
		
		ships.add(new ShipInfo(5, "porte-avion", 5, '5'));
		ships.add(new ShipInfo(4, "croiseur", 4, '4'));
		ships.add(new ShipInfo(3, "contre-torpilleur", 3, '3'));
		ships.add(new ShipInfo(33, "sous-marin", 3, 'S'));
		ships.add(new ShipInfo(2, "torpilleur", 2, '2'));
		
		return new Config(10, 10, ships);
	}
	
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public TpList<ShipInfo> getShips() {
		return ships;
	}
	
	public Board newBoard() {
		return new Board(this);
	}
	
	public Match newMatch() {
		return new Match(this);
	}
}





