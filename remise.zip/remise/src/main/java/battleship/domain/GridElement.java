
package battleship.domain;

import battleship.domain.util.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;
import battleship.domain.match.*;

public abstract class GridElement extends TpObject {
	
	protected Grid grid;
	protected CellList<Cell> cells;
	
	GridElement(Grid grid) {
		this.grid = grid;
		this.cells = new CellList<>();
	}
	
	public CellList<Cell> getCells() {
		return cells;
	}
	
	
	

}





