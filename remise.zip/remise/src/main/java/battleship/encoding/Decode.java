package battleship.encoding;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.opponent.IntelligentOpponent;
import battleship.opponent.RandomOpponent;
import battleship.domain.match.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;


import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import java.io.*;


public class Decode extends TpObject {
	
	String encoded;
	Match match;
	
	public Decode(String encoded) {
		this.encoded = encoded;
	}
	
	
	public Match decode() {
		try {
			return _decode();
		} catch (Exception e) {
			e.printStackTrace();
			assertThat(false);
			return null;
		}
	
	
	}
	
	public Match _decode() throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
				
		StringBuilder xmlStringBuilder = new StringBuilder();
		ByteArrayInputStream input =  new ByteArrayInputStream(encoded.getBytes("UTF-8"));
		Document doc = builder.parse(input);
		
		Element matchElement = doc.getDocumentElement();
		
		return decodeMatch(matchElement);
	}
	
	Match decodeMatch(Element matchElement) {
		
		Config config = decodeConfig((Element)matchElement.getElementsByTagName("Config").item(0));
		match = new Match(config);
		
		String algoName = matchElement.getAttribute("algo");
		
		if(algoName.equals("intelligent")) {
			match.setAlgo(new IntelligentOpponent(match.getAlgoGrid()));
		} else if (algoName.equals("random")) {
			match.setAlgo(new RandomOpponent(match.getAlgoGrid()));
		} else if (algoName.equals("")) {
			
		} else {
			assertThat(false);
		}
		
		match.setSide1(decodeMatchSide((Element)matchElement.getElementsByTagName("MatchSide").item(0)));
		match.setSide2(decodeMatchSide((Element)matchElement.getElementsByTagName("MatchSide").item(1)));
		
		return match;
	}
	
	MatchSide decodeMatchSide(Element sideElement) {
		MatchSide side = new MatchSide(match);
		Board board = decodeBoard((Element)sideElement.getElementsByTagName("Board").item(0));
		side.setBoard(board);
		return side;
	}
	
	Board decodeBoard(Element boardElement) {
		PersonalGrid ownGrid = decodePersonalGrid((Element)boardElement.getElementsByTagName("PersonalGrid").item(0));
		OpponentGrid opGrid = decodeOpponentGrid((Element)boardElement.getElementsByTagName("OpponentGrid").item(0));
		Board board = new Board(match.getConfig());
		board.setOwnGrid(ownGrid);
		board.setOpGrid(opGrid);
		return board;
	}
	
	PersonalGrid decodePersonalGrid(Element ownGridElement) {
		PersonalGrid ownGrid = new PersonalGrid(match.getConfig());
		decodePersonalShips(ownGrid, (Element)ownGridElement.getElementsByTagName("PersonalShips").item(0));
		decodePersonalTorpedos(ownGrid, (Element)ownGridElement.getElementsByTagName("PersonalTorpedos").item(0));
		return ownGrid;
	}
	
	void decodePersonalTorpedos(PersonalGrid ownGrid, Element torpedosElement) {
		
		NodeList torpedosNodeList = torpedosElement.getElementsByTagName("PersonalTorpedo");
		Element torpedoNode;
		String cellName;

		for(int i: Util.range(torpedosNodeList.getLength())) {
			torpedoNode = (Element)torpedosNodeList.item(i);
			cellName = torpedoNode.getAttribute("cellName");
			ownGrid.newTorpedoAtCellName(cellName);
		}

	}
	
	
	void decodePersonalShips(PersonalGrid ownGrid, Element shipsElement) {
		
		NodeList shipsNodeList = shipsElement.getElementsByTagName("PersonalShip");
		Element shipNode;
		String cellName;
		String orientationName;
		int shipIdent;
		PersonalShip ship;

		for(int i: Util.range(shipsNodeList.getLength())) {
			shipNode = (Element)shipsNodeList.item(i);
			
			cellName = shipNode.getAttribute("cellName");
			orientationName = shipNode.getAttribute("orientation");
			shipIdent = Integer.valueOf(shipNode.getAttributeNode("ident").getTextContent());
			ship = (PersonalShip)ownGrid.shipFromIdent(shipIdent);
			
			if(!cellName.isEmpty()) {
				try {
					ship.placeAtCellName(cellName, Orientation.fromName(orientationName));
				} catch (InvalidShipPosition e) {
					assertThat(false);
				}
			}
		}

	}
	
	
	
	OpponentGrid decodeOpponentGrid(Element opGridElement) {
		OpponentGrid opGrid = new OpponentGrid(match.getConfig());
		decodeOpponentTorpedos(opGrid, (Element)opGridElement.getElementsByTagName("OpponentTorpedos").item(0));
		return opGrid;
	}
	

	void decodeOpponentTorpedos(OpponentGrid opGrid, Element torpedosElement) {
		
		NodeList torpedosNodeList = torpedosElement.getElementsByTagName("OpponentTorpedo");
		Element torpedoNode;
		String cellName;
		int shipIdent;
		String feedbackSymbol;
		String shipCellName;
		String shipOrientationName;

		for(int i: Util.range(torpedosNodeList.getLength())) {
			torpedoNode = (Element)torpedosNodeList.item(i);
			
			cellName = torpedoNode.getAttribute("cellName");
			feedbackSymbol = torpedoNode.getAttribute("typeName");
			shipCellName = torpedoNode.getAttribute("shipCellName");
			shipOrientationName = torpedoNode.getAttribute("shipOrientationName");
			
			if(feedbackSymbol.equals("sinked")) {
				shipIdent = Integer.valueOf(torpedoNode.getAttribute("shipIdent"));
				opGrid.newTorpedoFromData(cellName, feedbackSymbol, shipIdent, shipCellName, shipOrientationName);
			} else {
				opGrid.newTorpedoFromData(cellName, feedbackSymbol, null, null, null);
			}
		}

	}
	
	
	Config decodeConfig(Element configElement) {
		int width = Integer.valueOf(configElement.getAttributes().getNamedItem("width").getTextContent());
		int height = Integer.valueOf(configElement.getAttributes().getNamedItem("height").getTextContent());
		TpList<ShipInfo> ships = decodeConfigShips((Element)configElement.getElementsByTagName("ShipInfos").item(0));
		
		return new Config(width, height, ships);
	}
	
	
	TpList<ShipInfo> decodeConfigShips(Element shipInfos) {
		TpList<ShipInfo> ships = new TpList<>();
		
		NodeList nodes = shipInfos.getElementsByTagName("ShipInfo");
		
		for(int i: Util.range(nodes.getLength())){
			ships.add(decodeConfigShip((Element)nodes.item(i)));
		}
		return ships;
	}
	
	ShipInfo decodeConfigShip(Element shipElement) {
		int ident = Integer.valueOf(shipElement.getAttributes().getNamedItem("ident").getTextContent());
		String name = shipElement.getAttributes().getNamedItem("name").getTextContent();
		int numCase = Integer.valueOf(shipElement.getAttributes().getNamedItem("numCase").getTextContent());
		char symbol = shipElement.getAttributes().getNamedItem("symbol").getTextContent().charAt(0);
		return new ShipInfo(ident, name, numCase, symbol);
	}
	
	
}





