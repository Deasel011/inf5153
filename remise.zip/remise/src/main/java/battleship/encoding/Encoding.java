package battleship.encoding;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;



public class Encoding {

	public Match decode(String encoded) {
		return new Decode(encoded).decode();
	}
	
	public String encode(Match match) {
		return new Encode(match).encode();
	}
	
	public void encodeToFile(Match match, String fpath) throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter(fpath, "UTF-8");
		writer.print(encode(match));
		writer.close();
	}
}





