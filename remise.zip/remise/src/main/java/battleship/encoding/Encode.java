package battleship.encoding;

import java.util.ArrayList;
import java.util.List;


import java.io.File;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


import battleship.domain.*;
import battleship.domain.util.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;



public class Encode extends TpObject {

    Document doc;
    Match match;
    
    public Encode(Match match) {
    	this.match = match;
    }
    
    public String encode() {
    	
    	try {
    		
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        doc = dBuilder.newDocument();
	        doc.appendChild(encodeMatch(match));
	        
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            DOMSource source = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            transformer.transform(source, result);
            return writer.toString();
            
         } catch (Exception e) {
            e.printStackTrace();
            assertThat(false);
            return null;
         }
    	
    	
    	

    	
//        //  supercars element
//        Element supercar = doc.createElement("supercars");
//        //matchElement.appendChild(supercar);
//
//        // setting attribute to element
//        Attr attr = doc.createAttribute("company");
//        attr.setValue("Ferrari");
//        supercar.setAttributeNode(attr);
//
//        // carname element
//        Element carname = doc.createElement("carname");
//        Attr attrType = doc.createAttribute("type");
//        attrType.setValue("formula one");
//        carname.setAttributeNode(attrType);
//        carname.appendChild(
//        doc.createTextNode("Ferrari 101"));
//        supercar.appendChild(carname);
//
//        Element carname1 = doc.createElement("carname");
//        Attr attrType1 = doc.createAttribute("type");
//        attrType1.setValue("sports");
//        carname1.setAttributeNode(attrType1);
//        carname1.appendChild(
//        doc.createTextNode("Ferrari 202"));
//        supercar.appendChild(carname1);

    	
    	
    	
        
    }
    
    
    public Element encodeConfig(Config config) {
    	
    	Element element = doc.createElement("Config");
    	element.setAttribute("width", "" + config.getWidth());
    	element.setAttribute("height", "" + config.getHeight());
    	element.appendChild(encodeShipInfos(config.getShips()));
    	return element;
    }
    
    public Element encodeShipInfos(TpList<ShipInfo> ships) {
    	Element shipsElement = doc.createElement("ShipInfos");
    	Element element;
    	
    	for(ShipInfo ship: ships) {
    		element = doc.createElement("ShipInfo");
    		element.setAttribute("name", ship.getName());
    		element.setAttribute("numCase", "" + ship.getNumCase());
    		element.setAttribute("ident", "" + ship.getIdent());
    		element.setAttribute("symbol", "" + ship.getSymbol());
    		shipsElement.appendChild(element);
    	}
    	return shipsElement;
    }
    
    
    public Element encodeMatch(Match match) {
    	Element matchElement = doc.createElement("Match");
    	
        if(match.getAlgo() == null) {
        	matchElement.setAttribute("algo", null);
        } else {
        	matchElement.setAttribute("algo", match.getAlgo().getName());
        }
    	
        matchElement.appendChild(encodeConfig(match.getConfig()));
        matchElement.appendChild(encodeSide(match.getSide1()));
        matchElement.appendChild(encodeSide(match.getSide2()));
        
        
        return matchElement;
    }
    
    
    public Element encodeSide(MatchSide matchSide) {
    	Element matchSideElement = doc.createElement("MatchSide");
    	matchSideElement.appendChild(encodeBoard(matchSide.getBoard()));
    	return matchSideElement;
    }
    
    
    public Element encodeBoard(Board board) {
    	Element boardElement = doc.createElement("Board");
    	
    	boardElement.appendChild(encodePersonalGrid(board.getOwnGrid()));
    	boardElement.appendChild(encodeOpponentGrid(board.getOpGrid()));
    	
    	return boardElement;
    }
    
    public Element encodePersonalGrid(PersonalGrid ownGrid) {
    	Element gridElement = doc.createElement("PersonalGrid");
    	
    	gridElement.appendChild(encodePersonalShips(ownGrid.getShipsPP()));
    	gridElement.appendChild(encodePersonalTorpedos(ownGrid.getTorpedos()));
    	
    	return gridElement;
    }
    
    public Element encodePersonalTorpedos(TpList<Torpedo> torpedos) {
    	Element element = doc.createElement("PersonalTorpedos");
    	
    	for(Torpedo torpedo: torpedos) {
    		element.appendChild(encodePersonalTorpedo((PersonalTorpedo)torpedo));
    	}
    	
    	return element;
    }
    
    
    public Element encodePersonalTorpedo(PersonalTorpedo torpedo) {
    	Element element = doc.createElement("PersonalTorpedo");
    	element.setAttribute("cellName", torpedo.getCell().getName());
    	return element;
    }
    
    public Element encodePersonalShips(TpList<PersonalShip> ships) {
    	Element element = doc.createElement("PersonalShips");
    	
    	for(PersonalShip ship: ships) {
    		element.appendChild(encodePersonalShip(ship));
    	}
    	
    	return element;
    }
    
    public Element encodePersonalShip(PersonalShip ship) {
    	// cellName, Orientation,
    	Element element = doc.createElement("PersonalShip");
    	element.setAttribute("ident", "" + ship.getShipIdent());
    	if(ship.isPlaced()) {
    		element.setAttribute("cellName", ship.getCell().getName());
    		element.setAttribute("orientation", ship.getOrientation().getName());
    	} else {
    		element.setAttribute("cellName", null);
    		element.setAttribute("orientation", null);
    	}
    	
    	return element;
    }
    
    public Element encodeOpponentGrid(OpponentGrid opGrid) {
    	Element gridElement = doc.createElement("OpponentGrid");
    	
    	gridElement.appendChild(encodeOpponentTorpedos(opGrid.getTorpedos()));
    	
    	return gridElement;
    }
    
    public Element encodeOpponentTorpedos(TpList<Torpedo> torpedos) {
    	Element element = doc.createElement("OpponentTorpedos");
    	
    	for(Torpedo torpedo: torpedos) {
    		element.appendChild(encodeOpponentTorpedo((OpponentTorpedo)torpedo));
    	}
    	
    	return element;
    }    
    
    
    public Element encodeOpponentTorpedo(OpponentTorpedo torpedo) {
    	Element element = doc.createElement("OpponentTorpedo");
    	TorpedoFeedback feedback = torpedo.getFeedback();
    	element.setAttribute("typeName", feedback.getFeedbackTypeName());
    	element.setAttribute("cellName", feedback.getCellName());
    	if(feedback.isSinked()) {
    		element.setAttribute("shipIdent", "" + feedback.getShipIdent());
    		element.setAttribute("shipCellName", "" + feedback.getShipCellName());
    		element.setAttribute("shipOrientationName", "" + feedback.getShipOrientationName());
    	} else {
    		element.setAttribute("shipIdent", null);
    	}
    	return element;
    }
    
    

}





