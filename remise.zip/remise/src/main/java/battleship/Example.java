package battleship;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import battleship.domain.*;
import battleship.domain.util.*;
import battleship.encoding.Encoding;
import battleship.opponent.*;
import battleship.domain.match.*;
import battleship.domain.opponent.*;
import battleship.domain.personal.*;


class Example extends TpObject {

    public static void main(String[] args) throws InvalidShipPosition, MatchDoneException, UnplacedShipException, FileNotFoundException, UnsupportedEncodingException {
        new Example().examples();
    	//new Example().experim();
    }
    
    void out(Object mes) {
    	flush();
    	System.out.println(mes);
    	flush();
    }
    
    void err(Object mes) {
    	flush();
    	System.err.println(mes);
    	flush();
    }
    
    void flush() {
    	System.out.flush();
    	System.err.flush();
    }
    
    Match match;
    public void examples() throws InvalidShipPosition, MatchDoneException, UnplacedShipException {
    	
    	match = Match.createWithDefaultConfig();
    	
    	title("on commence avec 4 grilles vide");
    	showAllGrids();
    	
    	title("on place NOS navires, sauf 1.");
    	
    	match.getSide1().getOwnGrid().shipFromSymbol('2').placeAtCellName("H1", Orientation.down());
    	match.getSide1().getOwnGrid().shipFromSymbol('3').placeAtCellName("I7", Orientation.right());
    	match.getSide1().getOwnGrid().shipFromSymbol('S').placeAtCellName("B4", Orientation.right());
    	match.getSide1().getOwnGrid().shipFromSymbol('5').placeAtCellName("B11", Orientation.down());
    	
    	match.getSide1().getOwnGrid().show();
    	
    	title("on leve une erreur si on place le dernier navire sur un autre navire ou dans un mur...");
    	
    	try {
    		match.getSide1().getOwnGrid().shipFromSymbol('4').placeAtCellName("A4", Orientation.down());
    		assertThat(false);
    	} catch (InvalidShipPosition e) {}
    	
    	try {
    		match.getSide1().getOwnGrid().shipFromSymbol('4').placeAtCellName("B6", Orientation.down());
    		assertThat(false);
    	} catch (InvalidShipPosition e) {}
    	
    	try {
    		match.getSide1().getOwnGrid().shipFromSymbol('4').placeAtCellName("H10", Orientation.right());
    		assertThat(false);
    	} catch (InvalidShipPosition e) {}
    	
    	
    	title("on va placer notre dernier navire dans le coin...");
    	
    	match.getSide1().getOwnGrid().shipFromSymbol('4').placeAtCellName("J9", Orientation.right());
    	match.getSide1().getOwnGrid().show();
    	
    	title("on va utiliser l'algorithme intelligent (on peut le setter nimporte quand)");
    	
    	OpponentAlgorithm algo;
    	algo = new IntelligentOpponent(match.getSide1().getOpGrid()); // attention! il faut utiliser side1 (et non side2)
    	algo = new RandomOpponent(match.getSide1().getOpGrid());
    	match.setAlgo(algo);
    	
    	title("avant d'utiliser l'algo, il faut placer les navires de l'adversaire");
    	
    	match.getSide2().getOwnGrid().placeAllShipsRandomly();
    	
    	showAllGrids();
    	
    	title("on peut maintenant envoyer des torpilles et recevoir le feedback.");
    	
    	
    	out(match.getSide1().playAgainstOpponent("A1"));
    	err(match.getSide2().playAgainstOpponentWithAlgo());
    	
    	out(match.getSide1().playAgainstOpponent("A2"));
    	err(match.getSide2().playAgainstOpponentWithAlgo());
    	
    	out(match.getSide1().playAgainstOpponent("A3"));
    	err(match.getSide2().playAgainstOpponentWithAlgo());
    	
    	title("on va faire s'affronter les 2 cotés avec minimax");
    	
    	while(true) {
    		
    		try {
    			out("coup X");
    			showAllGrids();
	        	out(match.getSide1().playAgainstOpponentWithAlgo());
	        	out("coup YY");
	        	showAllGrids();
	        	err(match.getSide2().playAgainstOpponentWithAlgo());
	        	
    		} catch (MatchDoneException e) {
    			err("we have a winner! (use match.getWinner())");
    			break;
    		}
    		
    	}
    	
    	
    	
    	showAllGrids();


    	
    }
    
    
    public void experim() throws InvalidShipPosition, MatchDoneException, UnplacedShipException, FileNotFoundException, UnsupportedEncodingException {
    	
    	match = Match.createWithDefaultConfig();
    	OpponentAlgorithm algo = new IntelligentOpponent(match.getSide1().getOpGrid());
    	
    	
    	match.getSide1().getOwnGrid().shipFromSymbol('2').placeAtCellName("H1", Orientation.down());
    	match.getSide1().getOwnGrid().shipFromSymbol('3').placeAtCellName("I7", Orientation.right());
    	match.getSide1().getOwnGrid().shipFromSymbol('S').placeAtCellName("B4", Orientation.right());
    	match.getSide1().getOwnGrid().shipFromSymbol('5').placeAtCellName("B11", Orientation.down());
    	match.getSide1().getOwnGrid().shipFromSymbol('4').placeAtCellName("J9", Orientation.right());
    	
    	
    	match.getSide2().getOwnGrid().shipFromSymbol('2').placeAtCellName("H1", Orientation.down());
    	match.getSide2().getOwnGrid().shipFromSymbol('3').placeAtCellName("I7", Orientation.right());
    	match.getSide2().getOwnGrid().shipFromSymbol('S').placeAtCellName("B4", Orientation.right());
    	match.getSide2().getOwnGrid().shipFromSymbol('5').placeAtCellName("B11", Orientation.down());
    	match.getSide2().getOwnGrid().shipFromSymbol('4').placeAtCellName("J9", Orientation.right());

    	showAllGrids();
    	
    	out(match.getSide1().playAgainstOpponent("B4"));
    	err(match.getSide2().playAgainstOpponent("A1"));
    	
    	out(match.getSide1().playAgainstOpponent("B5"));
    	err(match.getSide2().playAgainstOpponent("A2"));
    	

    	out(match.getSide1().playAgainstOpponent("B6"));
    	
    	
//    	Encoding encoding = new Encoding();
//    	String encoded = encoding.encode(match);
//    	encoding.encodeToFile(match, "c:/battleship-encoded.xml");
//    	Match newMatch = encoding.decode(encoded);
//    	newMatch.assertSyncedSides();
//    	encoding.encodeToFile(newMatch, "c:/battleship-encoded.xml");
    	

    	showAllGrids();
    }
    
    void showAllGrids() {
    	out("Side1: ownGrid");
    	match.getSide1().getOwnGrid().show();
    	
    	out("Side1: opGrid");
    	match.getSide1().getOpGrid().show();
    	
    	out("Side2: ownGrid");
    	match.getSide2().getOwnGrid().show();
    	
    	out("Side2: opGrid");
    	match.getSide2().getOpGrid().show();
    }
    
    void title(String title) {
    	out("===============================================");
    	out(title);
    	out("===============================================");
    }

}





