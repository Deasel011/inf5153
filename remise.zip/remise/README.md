# UI_for_battleship
***************

DUMF17099303 - Fabrice Dumont
DESP08089209 - Philippe Deslongchamps

*************

Instruction comment compiler
*attention Java 8-64 bit requis pour librairie jogamp.JOAL

commande maven à partir du dossier source:
mvn package

commande pour démarrer le jeu:
java -jar target/battleship-jar-with-dependencies.jar



Instruction Comment Jouer
    Se référer au PDF Instructions.

Note:
    le dossier savedGames doit exister dans le dossier en cours. C'est dans ce dossier que le logiciel va enregistrer une partie.

